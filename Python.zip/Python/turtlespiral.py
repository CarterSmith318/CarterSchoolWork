import turtle

def makeSpiral(myTurtle, maxSide):

    for sideLength in range(1,maxSide+1,5):

        myTurtle.forward(sideLength)

        myTurtle.right(90)


gertrude = turtle.Turtle()

makeSpiral(gertrude, 500)

turtle.done()