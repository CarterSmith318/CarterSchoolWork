#Carter Smith
#Lab 4 part 2  Dictionary

# Step 1 - 6 part 1



# Step 7
def makeDictionary(names, scores):
    score_dict = dict(zip(names, scores))
    return score_dict

# Step 6
names = ['Joe', 'Tom', 'Barb', 'Sue', 'Sally']
scores = [10, 23, 13, 18, 12]

# Step 8
scoreDict = makeDictionary(names, scores)

# Step 9
print("Score Dictionary:")
print(scoreDict)

# Step 10
print("Score for 'Barb':", scoreDict['Barb'])

# Step 11
scoreDict['John'] = 19
print("Updated Score Dictionary (Added 'John' with score 19):")
print(scoreDict)

# Step 12
sorted_scores = sorted(scoreDict.values())
print("Sorted list of scores:")
print(sorted_scores)

# Step 13
def calculateAverage(scores):
    return sum(scores) / len(scores)

average_score = calculateAverage(scoreDict.values())
print("Average Score:", average_score)

# Step 14
scoreDict['Sally'] = 13
print("Updated Score for 'Sally' to 13:")
print(scoreDict)

# Step 15
del scoreDict['Tom']
print("Score Dictionary after deleting 'Tom':")
print(scoreDict)
