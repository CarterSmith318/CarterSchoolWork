with open("rainfall.txt", "r") as file:
    aLine = file.readline()

print(aLine)

with open("rainfall.txt", "r") as inFile:
    linelist = inFile.readlines()

    print(linelist)

with open("rainfall.txt", "r") as inFile:
    fileString = inFile.read()
       
print(fileString)