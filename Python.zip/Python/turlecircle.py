import turtle

def makePolygon(myTurtle, sideLength, numberOfSides):
    turnAngle = 360 / numberOfSides

    for i in range(numberOfSides): #Repeat numberOfSides times
        myTurtle.forward(sideLength)
        myTurtle.right(turnAngle)

def makeCircle(myTurtle,radias):
    circumference = 2 * 3.1415 * radias
    sideLength = circumference / 360
    makePolygon(myTurtle, sideLength, 360)

tony = turtle.Turtle()

#makePolygon(tony, 50, 3)

#makePolygon(tony, 100, 6)

#makePolygon(tony, 200, 9)

makeCircle(tony, 50)

turtle.done()
