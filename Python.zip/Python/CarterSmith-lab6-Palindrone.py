
def is_palindrome(word):
    
    #This function takes a string as a parameter and returns True if the string is a palindrome, and False otherwise.
    
    i = 0
    j = len(word) - 1
    while i < j:
        if word[i] != word[j]:
            return False
        i += 1
        j -= 1
    return True

def main():
    
    #This function asks the user to input a string and outputs whether the string is a palindrome.
    
    while True:
        word = input("Enter a word: ").lower()
        if is_palindrome(word):
            print(f"{word} is a palindrome.")
        else:
            print(f"{word} is not a palindrome.")
        run_again = input("Do you want to run again? (y/n): ")
        if run_again.lower() != "y":
            break

if __name__ == "__main__":
    main()
