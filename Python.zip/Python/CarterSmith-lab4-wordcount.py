
# Star wars quote counter
# Carter Smith
# Function to count words in a sentence
def count_words(sentence):
    words = sentence.split()
    return len(words)

# Main function
def main():
    # User input
    sentence = input("Enter a sentence: ")

    # Count words in the sentence
    word_count = count_words(sentence)

    # Output the result
    print("Number of words in the sentence:", word_count)

# Check if the script is run directly
if __name__ == "__main__":
    main() 


    