def scramble2Encrypt(plainText):
    evenChars = ""
    oddChars = ""
    
    charCount = 0

    for ch in plainText:
        if charCount % 2 == 0:
            evenChars = evenChars + ch
        else:
            oddChars = oddChars + ch

        charCount = charCount + 1

    cipherText = oddChars + evenChars

    return cipherText


def scramble2Decrypt(cypherText):
    halfLength = len(cypherText) // 2
    evenChars = cypherText[halfLength:]
    oddChars = cypherText[:halfLength]
    plaintext = ""

    for i in range(halfLength):
        plaintext = plaintext + evenChars[i]
        plaintext = plaintext + oddChars[i]

    if len(oddChars) < len(evenChars):
        plaintext = plaintext + evenChars[-1]
    
    return plaintext


print(scramble2Encrypt("Python Rocks!"))

print(scramble2Decrypt("yhnRcsPto ok!"))