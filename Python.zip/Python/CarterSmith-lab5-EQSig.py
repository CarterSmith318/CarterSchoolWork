# CarterSmith - Lab 5 - EQSig.py


import json
from urllib import request
import statistics

# Fetch earthquake data from the provided URL using urllib
url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson"
with request.urlopen(url) as response:
    data = json.loads(response.read())

# Extract earthquake significance (sig) values from the JSON data
earthquake_sig = [quake['properties']['sig'] for quake in data['features']]

# Calculate statistics
minimum_sig = min(earthquake_sig)
maximum_sig = max(earthquake_sig)
mean_sig = statistics.mean(earthquake_sig)
median_sig = statistics.median(earthquake_sig)
std_dev_sig = statistics.stdev(earthquake_sig)
mode_sig = statistics.multimode(earthquake_sig)

# Output the statistics
print("Minimum sig: {:.3f}".format(minimum_sig))
print("Maximum sig: {:.3f}".format(maximum_sig))
print("Mean sig: {:.3f}".format(mean_sig))
print("Median sig: {:.3f}".format(median_sig))
print("Standard Deviation of sig: {:.3f}".format(std_dev_sig))
print("Mode(s) of sig:", mode_sig)
