import turtle

fred = turtle.Turtle()

turtle.bgcolor("black")

# Define the function to draw concentric boxes
def draw_concentric_boxes(size, depth):
    # Base case: if depth is 0, return
    if depth == 0:
        return

    # list of colors to use
    colors = ["red", "blue", "green", "yellow", "orange"]

    # Move the turtle to the starting point
    fred.penup()
    fred.goto(-size/2, -size/2)
    fred.pendown()

    # Change the color based on the depth
    fred.color(colors[depth % len(colors)])

    # Draw a square
    for _ in range(4):
        fred.forward(size)
        fred.left(90)

    # Recursive call to draw concentric boxes with increased size 
    draw_concentric_boxes(size + 20, depth - 1)

# Set the Fred's speed to the maximum warp
fred.speed(0)

# Call the function to draw concentric boxes
draw_concentric_boxes(100, 20)

turtle.done()
