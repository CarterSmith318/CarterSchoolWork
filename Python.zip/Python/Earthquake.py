import csv # Import csv module

def makeDataList(dataName):

    with open("earthquakes.csv", "r") as inFile:
        dataList=[]

        csvReader = csv.reader(inFile)
        titles = next(csvReader)

        colNum = 0
        
        while colNum < len(titles) and titles[colNum] != dataName:
            colNum += 1
        
        if colNum == len(titles):
            print("Error: " + dataName + " not found.")

        else:
            for line in csvReader:
                dataList.append(float(line[colNum]))

    return dataList