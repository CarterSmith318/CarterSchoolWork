
def leibniz(terms):
    acc = 0    #initialize acc to 0
    num = 4   #initialize num to 4
    den = 1   #initialize den to 1

    for aTerm in range(terms):
        nextTerm = num/den * (-1)**aTerm
        acc = acc + nextTerm  #add nextTerm to acc
        den = den + 2         #increment den by 2

    return acc



for i in range(8,25000,8):
    print((i, leibniz(i))) 