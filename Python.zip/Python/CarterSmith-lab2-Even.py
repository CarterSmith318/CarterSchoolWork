def isEven(n):
    if n % 2 == 0:
        print("This number is even.")
    else:
        print("This number is odd.")



isEven(3)
    
