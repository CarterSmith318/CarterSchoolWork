import math

# Function to compute the circumference of a circle
def calculateCir(radius):
    circumference = 2 * math.pi * radius
    return circumference

# Function to compute the area of a circle
def calculateArea(radius):
    area = math.pi * (radius ** 2)
    return area


print(( "Area" , calculateArea(7), "Circumfrance" , calculateCir(7)))