#Last steps: for Star Fleet universal translator update for Piratese
#Carter Smith
#Local Date: 9/30/2021 // StarDate: 101376.52


def toPirate(sentence, translation_dict):
    # Separate words and punctuation marks
    words = sentence.split()
    pirate_words = []
    
    for word in words:
        # Extract punctuation marks from the word
        word_without_punct = ''.join(filter(str.isalpha, word))
        punctuations = ''.join(filter(lambda x: not x.isalnum(), word))
        
        # Capitalize the word without punctuation and check if it exists in the translation dictionary
        capitalized_word = word_without_punct.upper()
        pirate_word = translation_dict.get(capitalized_word, capitalized_word)
        
        # Add back the punctuation marks to the translated word
        pirate_words.append(pirate_word + punctuations)
    
    # Join the words to form the translated sentence and return
    pirate_sentence = ' '.join(pirate_words)
    return pirate_sentence

# Translation dictionary (all words are in uppercase)
EtoP = {
    "HELLO": "AVAST", "EXCUSE": "ARRR", "SIR": "MATEY", "BOY": "MATEY", "MAN": "MATEY",
    "MADAM": "PROUD BEAUTY", "WOMAN": "PROUD BEAUTY", "OFFICER": "FOUL BLAGGART",
    "THE": "TH'", "MY": "ME", "YOUR": "YER", "IS": "BE", "ARE": "BE",
    "KITCHEN": "GALLEY", "HOTEL": "FLEABAG INN"
}

# Test communication with locals
english_sentence = "Hello, sir! My kitchen is in the hotel."
pirate_translation = toPirate(english_sentence, EtoP)
print(pirate_translation)
