import turtle

def makeRectangle(myTurtle, sideLength1,sideLength2):
        
        for i in range(2): #Repeat 2 times
    
            myTurtle.forward(sideLength1) #S
    
            myTurtle.right(90)
    
            myTurtle.forward(sideLength2) #Side 2

            myTurtle.right(90)
    
        


gg = turtle.Turtle()

makeRectangle(gg, 50,100)

makeRectangle(gg, 100,200)

makeRectangle(gg, 200,300)

turtle.done()