def vignereIndex(keyletter, plainTextLetter):
    keyIndex = letterToIndex(keyletter)
    ptIndex = letterToIndex(plainTextLetter)
    newIdx = (ptIndex + keyIndex) % 26
    return indexToLetter(newIdx)




def letterToIndex(letter):
    from string import ascii_lowercase

    aplhabet = ascii_lowercase
    idx = aplhabet.find(letter)

    if idx == -1:
        print("Error: letter not in aplhabet")  # Letter Not found

    return idx


def indexToLetter(idx):
    from string import ascii_lowercase

    aplhabet = ascii_lowercase + " "
    letter = ""

    if idx >= len(aplhabet):
        print("Error: index out of range")  # Index out of range  
    elif idx < 0:
            print("Error: index out of range")  # Index out of range
    else:
            letter = aplhabet[idx]

    return letter


def encryptVignere():
    key = input("Enter key: ")
    plaintext = input("Enter plaintext: ")
    cipherText = ""
    keyLen = len(key)

    for i in range(len(plaintext)):
        ch = plaintext[i]
        if ch == " ":
            cipherText = ch + " " 
        else:
             cipherText = cipherText + vignereIndex(key[i % keyLen], ch)
    
    return cipherText

print(encryptVignere())