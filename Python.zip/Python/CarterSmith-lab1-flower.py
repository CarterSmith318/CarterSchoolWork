import turtle

import random

# Name: Carter Smith

def makePolygon(myTurtle, sideLength, numberOfSides):
    turnAngle = 360 / numberOfSides

    for i in range(numberOfSides): #Repeat numberOfSides times
        myTurtle.forward(sideLength)
        myTurtle.right(turnAngle)

def makeCircle(myTurtle,radias):
    circumference = 2 * 3.1415 * radias
    sideLength = circumference / 360
    makePolygon(myTurtle, sideLength, 360)

    

def makeRectangle(myTurtle, sideLength1,sideLength2):
        
        for i in range(2): #Repeat 2 times
    
            myTurtle.forward(sideLength1) #S
    
            myTurtle.right(90)
    
            myTurtle.forward(sideLength2) #Side 2

            myTurtle.right(90)


def makeSpiral(myTurtle, maxSide):

    for sideLength in range(1,maxSide+1,5):

        myTurtle.forward(sideLength)

        myTurtle.right(90)






flowerChild = turtle.Turtle()

turtle.bgcolor("black")


flowerChild.pensize(5)  



# petals


flowerChild.up()

flowerChild.goto(0,-40)

flowerChild.down()

flowerChild.pencolor("yellow")

makeCircle(flowerChild, 100)


flowerChild.up()

flowerChild.goto(-40,0)

flowerChild.down()

flowerChild.pencolor("yellow")

makeCircle(flowerChild, 100)



flowerChild.up()

flowerChild.goto(40,0)

flowerChild.down()

flowerChild.pencolor("yellow")

makeCircle(flowerChild, 100)


flowerChild.up()

flowerChild.goto(0,40)

flowerChild.down()

flowerChild.pencolor("yellow")

makeCircle(flowerChild, 100)



#center flower

flowerChild.pencolor("red")

flowerChild.up()

flowerChild.goto(0,-40)

flowerChild.down()

makeCircle(flowerChild, 60)



# central spire

flowerChild.up()

flowerChild.goto(0,-100)

flowerChild.down()

flowerChild.pencolor("blue")

makeSpiral(flowerChild, 50)



#stem

flowerChild.up()

flowerChild.goto(5,-340)

flowerChild.down()

flowerChild.pencolor("green")

makeRectangle(flowerChild, 10, 100)








turtle.done()
