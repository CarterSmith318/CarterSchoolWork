import turtle

def makeSquare(myTurtle, sideLength):

    for i in range(4): #Repeat 4 times

        myTurtle.forward(sideLength) #draw the side

        myTurtle.right(90)

    




gertrude = turtle.Turtle()

makeSquare(gertrude, 50)

makeSquare(gertrude, 100)

makeSquare(gertrude, 200)




turtle.done()