
def letterToIndex(letter):
    from string import ascii_lowercase

    aplhabet = ascii_lowercase
    idx = aplhabet.find(letter)

    if idx == -1:
        print("Error: letter not in aplhabet")  # Letter Not found

    return idx

def indexToLetter(idx):
    from string import ascii_lowercase

    aplhabet = ascii_lowercase + " "
    letter = ""

    if idx >= len(aplhabet):
        print("Error: index out of range")  # Index out of range  
    elif idx < 0:
            print("Error: index out of range")  # Index out of range
    else:
            letter = aplhabet[idx]

    return letter



print(letterToIndex('a'))



print(indexToLetter(0))

print(indexToLetter(25))