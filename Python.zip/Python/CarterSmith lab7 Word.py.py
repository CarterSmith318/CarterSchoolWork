
def wordPop(phrase, N):
    words = phrase.split()
    result = []
    for word in words:
        if len(word) == N:
            result.append(word)
    return result

def main():
    while True:
        phrase = input("Enter a phrase: ")
        N = int(input("Enter the word length to search for: "))
        words = wordPop(phrase, N)
        print(f"Words with length {N}: {words}")
        choice = input("Do you want to run the program again? (yes/no): ")
        if choice.lower() != "yes":
            break

if __name__ == "__main__":
    main()


