def is_palindrome(string):
    if len(string) <= 1:
        return True
    elif string[0] != string[-1]:
        return False
    else:
        return is_palindrome(string[1:-1])

user_input = ""
while user_input != "-1":
    user_input = input("Enter a string (-1 to exit): ")
    if user_input == "-1":
        break
    if is_palindrome(user_input):
        print("The string is a palindrome.")
    else:
        print("The string is not a palindrome.")
