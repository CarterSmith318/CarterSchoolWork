
def separate_filename(filename):
    name, extension = filename.split('.')
    return name, extension

def main():
    while True:
        try:
            filename = input("Enter a filename with extension: ")
            name, extension = separate_filename(filename)
            print("Filename: ", name)
            print("Extension: ", extension)
        except ValueError:
            print("Invalid input. Please enter a valid filename.")

        repeat = input("Do you want to run the program again? (yes/no): ")
        if repeat.lower() != "yes":
            break

if __name__ == "__main__":
    main()
