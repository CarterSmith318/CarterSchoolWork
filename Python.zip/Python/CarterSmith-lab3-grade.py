
def testGradeSorter():

    numGrade = int(input("Enter a numerical grade: "))

    lettergrade = ""

    if numGrade >= 90:
        print("A")
    elif numGrade >= 80:
        print("B")
    elif numGrade >= 70:
        print("C")
    elif numGrade >= 60:
        print("D")  
    else:
        print("F")
    return lettergrade

print(testGradeSorter())