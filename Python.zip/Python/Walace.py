
def wallis (pairs):
    acc = 1
    num = 2 #initialize num to 2

    for aPair in range(pairs):
        leftTerm = num/(num-1) #denominator is always 1 less than numerator
        rightTerm = num/(num+1) #denominator is always 1 more than numerator

        acc = acc * leftTerm * rightTerm 
        num = num + 2 #increment num by 2


    pi = acc * 2 #multiply acc by 2 to get pi
    return pi #send pi back to the caller

print(wallis(1000000))