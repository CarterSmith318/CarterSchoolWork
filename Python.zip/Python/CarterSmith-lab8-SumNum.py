# Define a recursive function 
def recursive_sum(numbers):
    # Base case: if the list is empty, return 0
    if len(numbers) == 0:
        return 0
    elif len(numbers) == 1:
        return numbers[0]
    else:
        # Recursive case: add the first number to the sum of the rest of the list
        return numbers[0] + recursive_sum(numbers[1:])

# Create a list of numbers
numbers = [10, 5, 3, 8, 2]

#should be 28

# Call the recursive_sum function with the numbers list
result = recursive_sum(numbers)

# Print the result
print(result)
