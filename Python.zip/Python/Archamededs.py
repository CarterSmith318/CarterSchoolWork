import math

def archimedes(numbSides): #assumtion that raduis is 1

    innerAngleB = 360/numbSides #determine the center angle
    halfAngleA = innerAngleB/2 # determine the triangle angle
    oneHalfSidesS = math.sin(math.radians(halfAngleA)) # determine the half of the side
    sideS = oneHalfSidesS * 2 #find the full side
    polygonCircumference = numbSides * sideS #find the distance around the polygon
    pi = polygonCircumference/2 # circumference / diameter
    return pi #send the value of pi back to the line that called it


for sides in range(8, 100, 8):
    print(sides, archimedes(sides))
