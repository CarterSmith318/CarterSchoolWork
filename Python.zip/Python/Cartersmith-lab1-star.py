import turtle

starChild = turtle.Turtle()

turtle.bgcolor("black")

starChild.pensize(5)

starChild.pencolor("yellow")

starChild.forward(100)

starChild.right(144)

starChild.forward(100)

starChild.right(144)


starChild.forward(100)

starChild.right(144)

starChild.forward(100)  

starChild.right(144)

starChild.forward(100)

turtle.done()


