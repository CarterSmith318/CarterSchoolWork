

name = "Carter Smith"

print(name [0:6]) # Carter

print(name [7:12]) # Smith

print(name [7:12] + ", " + name [0:6]) # Smith, Carter

s = 's'

p = 'p'

print( "mi" + s*2 + "i" + s*2 + "i" + p*2 + "i")

#mississippi