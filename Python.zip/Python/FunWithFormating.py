
fruitPrice = 75

fruit = "Apple"

print("The {0} cost {1:d} cents." .format(fruit, fruitPrice))

item = "a dozen eggs"

itemPrice = 2.4

print("The price of {0} is ${1:.2f}" . format(item, itemPrice) )

myDict = {'name':'candybar', 'price':95}

print("The {name} costs {price} cents." .format(**myDict))

print("This text is {0:^25s}" .format("centered"))

print("This text is {0:>25s}" .format("right justified"))

print("This text is {0:<25s}" .format("left justified"))

quizGrade = 7.5

totalPoints = 12

print("{0:.1f} is {1:.2%} of {2:d} total points" .format(quizGrade, quizGrade / totalPoints, totalPoints))

