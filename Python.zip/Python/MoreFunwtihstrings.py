team = "Minnasota Vikings"

print(team.split())

sentance = "Mary had a little lamb"

print(sentance.split())\


print(team.split("i"))

print(sentance.split("a"))