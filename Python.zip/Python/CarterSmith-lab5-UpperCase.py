# Carter Smith - Lab 5 - Uppercase.py

# Read the contents of the regular.txt file and convert to uppercase
with open("regular.txt", "r") as input_file:
    content = input_file.read()

# Convert the content to uppercase
uppercase_content = content.upper()

# Write the uppercase content to uppercase.txt
with open("uppercase.txt", "w") as output_file:
    output_file.write(uppercase_content)

print("Contents of regular.txt have been converted to uppercase and saved in uppercase.txt.")
