def stripSpaces(myString):
    
    result = ""

    # Loop through each character in the input string
    for char in myString:
        # Check if the character is not a space
        if char != ' ':
            
            result += char

    return result

# Get input from the user
myString = input("Enter a phrase: ")

# Call the function
stripped_phrase = stripSpaces(myString)
print("Modified phrase:", stripped_phrase)
