
ages ={'David':45, 'Brendan': 46}

print(ages)

print(ages['David'])

ages['Kelsey'] = 19

print(ages)

ages['Hannah'] = 16
ages['Rylea'] = 7

print(ages)

print(len(ages))

ages['David'] = ages['David'] + 1

print(ages)

print(ages.keys())

print(ages.values())

keysList = list(ages.keys())

print(keysList)

print(ages.items())

print(ages.get('Lena', 'No age listed'))

print('Rylea' in ages)

print('Lena' in ages)