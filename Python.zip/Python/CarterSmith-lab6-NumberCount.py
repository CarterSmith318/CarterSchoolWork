
def number_count():
    while True:
        start = int(input("Enter start value: "))
        end = int(input("Enter end value: "))
        step = int(input("Enter step value: "))
        if start > end:
            print("Start value cannot be greater than end value.")
            continue
        current = start
        while current <= end:
            print(current)
            current += step
        run_again = input("Do you want to run again? (y/n): ")
        if run_again.lower() != "y":
            break

number_count()