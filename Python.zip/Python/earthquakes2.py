import json
import urllib.request
import statistics

def makeMagList(earthquakeData):
    magList = []
    
    earthquake = earthquakeData.get("features")

    for i in range(len(earthquake)):
        earthquake = earthquake[i]
        properties = earthquake.get("properties")
        mag = properties.get("mag")
        magList.append(mag)

    return magList

handel = urllib.request.urlopen("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson")
data = handel.read()
eData = json.loads(data)
magList = makeMagList(eData)

