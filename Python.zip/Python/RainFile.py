

#fileRef = open("rainfall.txt", "r") # open file for reading

#fileRef.close()

with open("rainfall.txt", "r") as rainFile:
    with open("rainfallInCm.txt", "w") as outfile:
        for aLine in rainFile:
            values = aLine.split()
            print("{0}, had {1:2.2f}, inches of rain.".format(values[0], float(values[1]))) 

            inches = float(values[1]) # convert string to float
            cm = inches * 2.54

            outfile.write(values[0] + " " + str(cm) + "\n")
