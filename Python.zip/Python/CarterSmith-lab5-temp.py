

# Carter Smith Lab 5 - TempConvert.py

def write_temp_conversion_table():
    with open("tempConv.txt", "w") as file:
        file.write("{:<10} {:<10}\n".format("Fahrenheit", "Celsius"))
        for fahrenheit in range(-300, 213):
            celsius = (fahrenheit - 32) * 5.0/9.0
            file.write("{:<10.3f} {:<10.3f}\n".format(fahrenheit, celsius))

# Call the function to generate the temperature conversion table and write it to the file
write_temp_conversion_table()
