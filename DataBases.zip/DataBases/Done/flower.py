print("Welcome to my computer quiz!")

playing = input("Do you want to play? ")

if playing != "yes":
    quit()

print("Okay! Lets Play!")
score = 0

answer = input("What does CPU stand for? ")
if answer == "central processing unit":
    print("correct")
    score += 1
else:
    print("incorrect")

print ("You got " + str(score) + "questions correct!")