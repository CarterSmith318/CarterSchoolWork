alter table OrdersData add check(orderTotal >= 0);


