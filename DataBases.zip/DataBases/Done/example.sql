create table Deptments(dname varchar(25), budget float, did int not null primary key);

drop table Deptments;

INSERT INTO Deptments(dname, budget, did)
values ('Mathematics', 100000000,0), ('English', 3,1);

select * from Deptments;