create database college;

create table students(studentID int,
fName varchar(256),
lName varchar(256),
DoB date,
gender char(1),
address varchar(256), 
phoneNo varchar(256),
email varchar(256),
Major varchar(256),
academicStanding smallint,
gpa float,
creditsEarned int,
advisor varchar(256),
startDate date,
graduationDate date,
financailAidStatus varchar(256),
residancyStatus bit,
campusLocation varchar(256));

select * from students;

alter table students add SSN char(11), athlete bit;

alter table students alter column studentID int not null;

alter table students add primary key (studentID);

create table gender(genderID int primary key,
genderShort varchar(8),
genderName varchar(256));


alter table students drop constraint PK__students__4D11D65C20BC6A4C;

alter table students drop column studentID;

alter table students add studentID int identity(1000,1) primary key;

select * from students;

alter table gender drop constraint PK__gender__306E2220F378548F;


alter table gender drop column genderID;

alter table gender add genderID int identity(2000,1) primary key;

alter table students alter column genderID int;

alter table students add constraint genderID foreign key (genderID) references gender(genderID) ;

create table addresses (addressID int identity (3000,1) primary key,
	buildingNum int,
	streetName varchar(256),
	cityID int foreign key(cityID) references city(cityID),
	postalCodeID int foreign key(postalCodeID) references postalCode(postalCodeID));


create table city(cityID int identity(4000,1) primary key,
cityName varchar(256),
stateProvidanceID int foreign key(stateProvidanceID) references stateProvidance(stateProvidenceID));

create table stateProvidance(stateProvidenceID int identity(5000,1) primary key,
stateProvidenceName varchar(256),
countryID int foreign key(countryID) references country(countryID));



create table country(countryID int identity (6000,1) primary key,
countryName varchar(256),counrtyPostalCode int)

create table postalCode(postalCodeID int primary key identity(7000,1),
postalCode varchar(256),
countryPostalCode varchar(256));

alter table country drop column counrtyPostalCode;

select * from country;

create table adressesRef(studentID int  foreign key (studentID) references students(studentID),
addressID int foreign key (addressID) references addresses(addressID),
primary key(studentID, addressID))

create table phoneNo(phoneNoID int primary key identity(8000, 1), 
countryCode varchar(4), 
areaCode varchar(4), 
prefix varchar(4),
suffix varchar(4),
extension varchar(8)) 

create table emailAddress(emailaddressID int primary key identity (9000,1),
username varchar(256), domainID int foreign key (domainID) references domain(domainID));

create table domain(domainID int primary key identity(10000, 1),
domain varchar(256));

create table emailAddressRef(studentID int foreign key (studentID) references students(studentID),
emailAddressID int foreign key (emailaddressID) references emailAddress(emailaddressID),
primary key (studentID,emailaddressID));
--------------------------------------------------------------------------------
create table major(majorID int primary identity(11000, 1),
majorName varchar(256),
DepartmentID int foreign key,


create table department(departmentID int primary key identity(12000,1), departmentName varchar(256), staffID int foreign key

create table staff(staffID int primary key identity(13000,1), 