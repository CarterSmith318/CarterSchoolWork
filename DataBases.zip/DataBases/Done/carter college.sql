create table person(personID int identity (1000,1) primary key,
fname varchar (256),
lname varchar (256),
DoB date,
genderID int foreign key /////,
SSN char(11),
adressID int foreign key (addressID) references addresses(addressID),
emailID int foreign key //////,
phoneNoID int foreign key (phoneNoID) references phoneNo(phoneNoID),
ethnicityID int foreign key/////,

create table student (startDate date,
endDate date,
majorID foreign key////,
academicID foreign key//////,
personID int foreign key (personID) references person(personID),



create table addresses (addressID int identity (3000,1) primary key,
	buildingNum int,
	streetName varchar(256),
	cityID int foreign key(cityID) references city(cityID),
	postalCodeID int foreign key(postalCodeID) references postalCode(postalCodeID));


create table city(cityID int identity(4000,1) primary key,
cityName varchar(256),
stateProvidanceID int foreign key(stateProvidanceID) references stateProvidance(stateProvidenceID));

create table stateProvidance(stateProvidenceID int identity(5000,1) primary key,
stateProvidenceName varchar(256),
countryID int foreign key(countryID) references country(countryID));



create table country(countryID int identity (6000,1) primary key,
countryName varchar(256))

create table postalCode(postalCodeID int primary key identity(7000,1),
postalCode varchar(256),
countryPostalCode varchar(256));

create table adressesRef(personID int  foreign key (personID) references person(personID),
addressID int foreign key (addressID) references addresses(addressID),
primary key(personID, addressID))


create table phoneNo(phoneNoID int primary key identity(8000, 1), 
countryCode varchar(4), 
areaCode varchar(4), 
prefix varchar(4),
suffix varchar(4),
extension varchar(8))


create table emailAddress(emailaddressID int primary key identity (9000,1),
username varchar(256), domainID int foreign key (domainID) references domain(domainID));

create table domain(domainID int primary key identity(10000, 1),
domain varchar(256));

create table emailAddressRef(personID int  foreign key (personID) references person(personID),
emailAddressID int foreign key (emailaddressID) references emailAddress(emailaddressID),
primary key (personID,emailaddressID));

create table major(majorID int primary identity(11000, 1),
majorName varchar(256),
departmentID int foreign key (departmentID) references department(departmentID),


create table department(departmentID int primary key identity(12000,1), departmentName varchar(256), 
staffID int foreign key (staffID) references staff(staffID));

create table staff(staffID int primary key identity(13000,1),
startDate date,
endDate date,

------------------------------------------------------------------------------------------------

create table buildings(buildingID int primary key identity (14000,1), BuildingName varchar(256), staffID int foreign key (staffID) references 

