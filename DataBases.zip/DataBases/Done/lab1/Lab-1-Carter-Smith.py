
file = open("customer.txt")
for line in file:
    if '1' in line:

      print(line)




