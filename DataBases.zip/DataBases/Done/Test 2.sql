-- Primary keys---------

alter table Address add constraint pk_address PRIMARY KEY (addressID)

alter table CustmerAddressRefData add constraint pk_CustomerAddressRefData PRIMARY KEY (customerID,addressID)

alter table CustomerData add constraint pk_CustomerData PRIMARY KEY (customerID)

alter table DepartmentData add constraint pk_DepartmentData PRIMARY KEY (departmentID)

alter table EmployeeAddressRefData add constraint pk_EmployeeAddressRefData PRIMARY KEY (employeeID,addressID)
alter table EmployeeData add constraint pk_EmployeeData PRIMARY KEY (employeeID)
alter table OrdersItemsRefData add constraint pk_OrdersItemsRefData PRIMARY KEY (orderID,itemID)
alter table OrdersData add constraint pk_OrdersData PRIMARY KEY (orderID)
select * from ItemLocationRefData
alter table ItemLocationRefData add constraint pk_ItemLocationRefData Primary Key (itemID,warehouseID,locationID)
alter table drop ItemLocationRefData
alter table OrdersData add constraint pk_OrdersData Primary Key (orderID)
alter table TaxesData add constraint pk_TaxesData Primary Key (taxID) -- Chapter 4 index defintions in sql end of chapter 4 slides
alter table WarehouseData add constraint pk_WarehouseData Primary Key (warehouseID)
-------foreign keys------

alter table CustomerAddressRefData add constraint fk_CustomerAddressRefDataCus Foreign Key (customerID) References CustomerData (customerID)

alter TABLE CustomerAddressRefData ADD CONSTRAINT fk_CustomerAddressRefDataADD FOREIGN KEY (addressID) REFERENCES Address (addressID)

alter TABLE EmployeeAddressRefData ADD CONSTRAINT fk_EmployeeAddressRefDataEm FOREIGN KEY (employeeID) REFERENCES EmployeeData (employeeData)

alter TABLE  EmployeeAddressRefData ADD CONSTRAINT fk_EmployeeAddressRefDataADD FOREIGN KEY (addressID) REFERENCES Address (addressID)

alter TABLE EmployeeData ADD CONSTRAINT fk_EmployeeDataDept FOREIGN KEY (departmentID) REFERENCES DepartmentData (departmentID)

alter TABLE EmployeeData ADD CONSTRAINT fk_EmployeeDataEm FOREIGN KEY (employeeID) REFERENCES EmployeeData (employeeID)

alter TABLE EmployeeData ADD CONSTRAINT fk_EmployeeDataWare FOREIGN KEY (warehouseID) REFERENCES WarehouseData (warehouseID)

alter TABLE ItemLocationRefData ADD CONSTRAINT fk_ItemLocRefDataitem FOREIGN KEY (itemID) REFERENCES ItemData(itemID)

alter TABLE ItemLocationRefData ADD CONSTRAINT fk_ItemLocRefDataWare FOREIGN KEY (warehouseID) REFERENCES WarehouseData(warehouseID)


alter TABLE OrdersData ADD CONSTRAINT fk_OrdersDatacus FOREIGN KEY (customerID) REFERENCES CustomerData (customerID)

alter TABLE OrdersData ADD CONSTRAINT fk_OrdersDataTax FOREIGN KEY (taxID) REFERENCES TaxesData (taxID)

alter TABLE OrdersItemsRefData ADD CONSTRAINT fk_OrdersRefOrder FOREIGN KEY (orderID) REFERENCES OrdersData (orderID)

alter TABLE OrdersItemsRefData ADD CONSTRAINT fk_OrdersRefItem FOREIGN KEY (itemID) REFERENCES ItemData (ItemID)

alter TABLE TaxesData ADD CONSTRAINT fk_TaxesDataADD FOREIGN KEY (addressID) REFERENCES Address (addressID)

alter TABLE WarehouseData ADD CONSTRAINT fk_WarehouseDataADD FOREIGN KEY (addressID) REFERENCES Address (addressID)


alter TABLE  ADD CONSTRAINT fk_ FOREIGN KEY () REFERENCES ()

alter TABLE  ADD CONSTRAINT fk_ FOREIGN KEY () REFERENCES ()

alter table CustomerAddressRefData add constraint fk_CustomerAddressRefData Foreign Key CustomerAddressRefData (addressID) references Address

-------Contraints-------------------------

ALTER TABLE TaxesData ALTER COLUMN taxID int NOT NULL

ALTER TABLE EmployeeData ALTER COLUMN employeeID int NOT NULL

ALTER TABLE CustomerData ALTER COLUMN customerID int NOT NULL

ALTER TABLE CustomerData ALTER COLUMN customerJoinDate date NOT NULL

ALTER TABLE CustomerData ADD CONSTRAINT PhoneNo CHECK (LEN(PhoneNo) > 0);

ALTER TABLE EmployeeData ADD CONSTRAINT fName CHECK (LEN(fName) > 0)

ALTER TABLE EmployeeData ADD CONSTRAINT lName CHECK (LEN(lName) > 0)

ALTER TABLE CustomerData ADD CONSTRAINT fName CHECK (LEN(fName) > 0)

ALTER TABLE CustomerData ADD CONSTRAINT lName CHECK (LEN(lName) > 0)

ALTER TABLE ItemData ADD constraint df_itemName DEFAULT 'Item Description' for itemName

ALTER TABLE ItemData ADd constraint df_price DEFAULT '0.00' for price














--Int from small int ----------------------------------------------------------------------------------------------------------------
alter table address alter column houseNo int
alter table CustomerAddressRefData alter column customerID int
alter table CustomerAddressRefData alter column addressID int
alter table CustomerData alter column customerID int
alter table ItemLocationRefData alter column itemID int ---- why?
UPDATE ItemLocationRefData SET itemID = Cast(itemID AS int) --- nope


--alter table 

--alter table Address drop pk_address

------------------------------------------------------------------------
--Old
/*select TOP 10 
 Group by CustomerData.customerID,
 Sum(OrdersData.orderID) as ordercount,
 FROM
    CustomersData
    INNER JOIN OrdersData ON CustomerData.CustomerID = OrderData.CustomerID
GROUP BY
    CustomerData.fName
ORDER BY
    OrderCount DESC;*/

	---Customer Order-------------------------------
	SELECT TOP 10
    CustomerData.CustomerID,
    CustomerData.fName + ' ' + CustomerData.lName AS CustomerName,
    COUNT(OrdersData.OrderID) AS OrderCount,
	(CustomerData.customerJoinDate) AS JoinDate
FROM
    CustomerData
    INNER JOIN OrdersData ON CustomerData.CustomerID = OrdersData.CustomerID
GROUP BY
    CustomerData.CustomerID, CustomerData.fName, CustomerData.lName,CustomerData.customerJoinDate
ORDER BY
    OrderCount DESC;

--- Items--------------------------------------------
select * from ItemData, OrdersItemsRefData,OrdersData

	SELECT TOP 10
    ItemData.itemName,
    OrdersItemsRefData.itemID,
    SUM(OrdersItemsRefData.itemAmount) AS TotalItemsSold,
    SUM(OrdersItemsRefData.itemAmount * ItemData.price) AS TotalSales
FROM
    ItemData
    INNER JOIN OrdersItemsRefData ON ItemData.itemID = OrdersItemsRefData.itemID
GROUP BY
    ItemData.itemName,
    OrdersItemsRefData.itemID
ORDER BY
    TotalItemsSold DESC;


---Warehouse ------------------------------
---- Converson failure on itemID in ItemLocRefData from nvarchar to int, cast no go
	SELECT TOP 3
    EmployeeData.fName AS WorkerName,
    WarehouseData.warehouseID AS WarehouseID,
    SUM(OrdersItemsRefData.itemAmount * ItemData.price) AS TotalSales
FROM
    EmployeeData
    INNER JOIN EmployeeAddressRefData ON EmployeeData.employeeID = EmployeeAddressRefData.employeeID
    INNER JOIN WarehouseData ON WarehouseData.addressID = EmployeeAddressRefData.addressID
    INNER JOIN ItemLocationRefData ON EmployeeData.warehouseID = ItemLocationRefData.warehouseID
    INNER JOIN OrdersItemsRefData ON ItemLocationRefData.itemID = OrdersItemsRefData.itemID
    INNER JOIN ItemData ON OrdersItemsRefData.itemID = ItemData.itemID
    INNER JOIN OrdersData ON OrdersItemsRefData.orderID = OrdersData.orderID
GROUP BY
    EmployeeData.fName,
    WarehouseData.warehouseID
ORDER BY
    TotalSales DESC;
	---------------------------------


	---Indexes--------------------------------
	CREATE INDEX idx_ItemData_itemName ON ItemData (itemName)

	CREATE INDEX idx_Address_addressID ON Address (addressID)

	CREATE INDEX idx_Dept_DeptID ON DepartmentData (departmentID);

	CREATE INDEX idx_Orders_orderID ON OrdersData (orderID);

	CREATE INDEX idx_WH_wareID ON WarehouseData (warehouseID);

	CREATE INDEX idx_Cus_CusID ON CustomerData (customerID);

	CREATE INDEX idx_em_emID ON EmployeeData (employeeID);








