# generate states names

import random


prefixes = ['North', 'South', 'East', 'West', 'Central', 'Mid', 'New', 'Old', 'Upper', 'Lower']
suffixes = ['mont', 'vania', 'tica', 'terra', 'landia', 'sota', 'lina', 'rado', 'dale', 'tonia']


for i in range(10):
    stateName = random.choice(prefixes) + random.choice(suffixes)
    print(stateName)


# county gen

    prefixes2 = ['New', 'North', 'South', 'East', 'West']
    suffixes2 = ['shire', 'field', 'ton', 'land', 'ford', 'bury', 'dale']
    
for i in range(10):
    countyName = random.choice(prefixes2) + random.choice(suffixes2)
    print(countyName)


# city gen


    prefixes3 = ['New', 'Old', 'North', 'South', 'East', 'West']
    suffixes3 = ['town', 'ville', 'ton', 'field', 'borough', 'bury', 'ford']
   
for i in range(10):
    cityName = random.choice(prefixes3) + random.choice(suffixes3)
    print(cityName)


#tax gen ---------

# State 
for i in range(10):
    state_tax_rates = (round(random.uniform(3, 8), 1))
    print(state_tax_rates)

# County 
for i in range(10):
    county_tax_rates=(round(random.uniform(1, 5), 1))
    print(county_tax_rates)

# City
for i in range(10):
    city_tax_rates = (round(random.uniform(0.5, 3), 1))
    print(city_tax_rates)





