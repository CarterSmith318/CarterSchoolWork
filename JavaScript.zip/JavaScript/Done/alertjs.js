function showMessage1()
{

window.alert("This is an alert #1!");
}

function showMessage2()
{
window.alert("This is alert #2");
}


showMessage2();
showMessage1();