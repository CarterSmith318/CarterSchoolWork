let HourRate = window.prompt("Hello, and Welcome to Gross pay Calculator. What is your hourly rate?", "");
let HoursWorked = window.prompt("Wonderfull! Now tell me your hours worked this week.", "");

var p = ("<p>");
var ep = ("</p>");

if (HoursWorked <= 40){

	var Under = (HourRate * HoursWorked);

	document.write(p + "Your Gross Pay is $" + Under + "!" + ep);
	document.write(p + "Regular Hours " + HoursWorked + ep);
	document.write(p + "Hourly Rate is $" + HourRate + ep);

}

else{
	var QM = (HourRate * 40);
	var Over = (HoursWorked - 40); 
	var OverTime = (((HourRate * 1.5) * Over) + QM);
	

	document.write(p + "Your Gross Pay is $" + OverTime + "!" + ep);
	document.write(p + "Regular Hours 40" +ep);
	document.write(p + "Over Time Hours " + Over + ep);
	document.write(p + "Hourly Rate is $" + HourRate + ep);
	document.write(p + "Over Time Hourly Rate is $" + (1.5 * HourRate) + ep);

};
