var intSpan = document.getElementById("int");

intSpan.addEventListener("mouseover", function() {
  intSpan.style.color = "#FF1493";
});

intSpan.addEventListener("mouseout", function() {
  intSpan.style.color = "#0000FF";
});
