let num1 = 5;
let num2 = 7;
if (num1 > num2) 
{
    window.alert("True");
}
else 
{
     window.alert("False");
}




//True step 5
//False step 6
//True step 8
//False step 10

var p = "<p>";
var ep = "</p>";

document.write(p + 'True step 5' + ep)
document.write(p + 'False step 6' + ep)
document.write(p + 'True step 8' + ep)
document.write(p + 'False step 10' + ep)
