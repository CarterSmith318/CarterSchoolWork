function Student(name,age,sport,gender,housing) {

this.name = name;
this.age = age;
this.sport = sport;
this.gender = gender;
this.housing = housing;




}


let Student1 = new Student("Carter",26,"Going Home Club", "Male","Off Campus");

Student1.age = Student1.age++;

let Student2 = new Student();

Student2.name = window.prompt("What is your Name?");

Student2.age = window.prompt("What is your Age?");

Student2.sport = window.prompt("What is your Sport?");

Student2.gender = window.prompt("What is your gender?");

Student2.housing = window.prompt("Do you live on campus?");










