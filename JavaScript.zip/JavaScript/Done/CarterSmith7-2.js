let computerParts = [["Monitors", "LCD Screens", "Vibrant Colors"], ["Motherboards", "Fast"],
["Chips", "Pentium", "Very Fast"], ["Hard Drives", "100-500GB", "Fast Reading"],["DVD-Roms","Burning CDs","Burn DVDs", "Listens to both!"],
["Cases", "All Sizes", "Choice of Colors"],["Power Supplies", "We can get one for any computer!"]];

var length = computerParts.length;

for (i = 0; i < computerParts.length; i++) 
{

	for (j = 0; j < computerParts[i].length; j++) 
	{
		document.write(computerParts[i][j]);

		if (j == 0)
		{
			document.write(": ");
		}
		else if(j == computer[i].length - 1) 	
		{
			document.write("<br>");

		}
 		else
		{ 
			document.write(", ");

		}
	}
}



	


