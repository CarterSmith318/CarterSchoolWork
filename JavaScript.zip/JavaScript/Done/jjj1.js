var priceOfGas = 3.09;
var gallons = 10.549;
var cost = (priceOfGas * gallons);
var playAgain = true;
var nothing = null;
var beginPara = "<p>";
var endPara = "</p>";

document.write(beginPara + "John said, \"This project was a piece of cake!\"" + endPara)


document.write(cost)