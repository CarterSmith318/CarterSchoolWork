var taxRate = 0.07
var taxableSale = 85.99 
var taxFreeSale = 18.95

function salesTax(taxRate, taxableSale)
{
var RealSalesTax = taxRate * taxableSale

return (RealSalesTax)

}


var totalTaxamount = salesTax(taxRate, taxableSale)



function totalDue(totalTaxamount, taxFreeSale, taxableSale)
{

var TTtotal = totalTaxamount + taxFreeSale + taxableSale

return (TTtotal)

}


var FinishedTotal = totalDue(totalTaxamount, taxFreeSale, taxableSale)

window.alert("Your Total is $" + FinishedTotal + "!")