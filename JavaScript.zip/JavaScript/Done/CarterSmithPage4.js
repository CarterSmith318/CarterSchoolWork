const natoAlphabet = {
    'A': 'Alpha',
    'B': 'Bravo',
    'C': 'Charlie',
    'D': 'Delta',
    'E': 'Echo',
    'F': 'Foxtrot',
    'G': 'Golf',
    'H': 'Hotel',
    'I': 'India',
    'J': 'Juliet',
    'K': 'Kilo',
    'L': 'Lima',
    'M': 'Mike',
    'N': 'November',
    'O': 'Oscar',
    'P': 'Papa',
    'Q': 'Quebec',
    'R': 'Romeo',
    'S': 'Sierra',
    'T': 'Tango',
    'U': 'Uniform',
    'V': 'Victor',
    'W': 'Whiskey',
    'X': 'Xray',
    'Y': 'Yankee',
    'Z': 'Zulu'
  };
  
  const form = document.querySelector('form');
  const result = document.getElementById('result');
  
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = document.getElementById('name').value.toUpperCase();
    let convertedName = '';
  
    for (let i = 0; i < name.length; i++) {
      const letter = name[i];
      if (natoAlphabet[letter]) {
        convertedName += natoAlphabet[letter] + ' ';
      }
    }
  
    result.textContent = `Your name in the NATO phonetic alphabet: ${convertedName}`;
  });
  