function carCost()
{



window.alert("You have a " + myCar + " and make $" + paycheck)


}

function getAddedText()
{

window.alert("This project " + "is fun like all of our projects in this class!")

}


var myCar = "Ferarri"

var paycheck = 8500

carCost();



var alertText = getAddedText

alertText()




