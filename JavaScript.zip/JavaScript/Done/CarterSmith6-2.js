var msg = ("");

var city = window.prompt("What is the name of your city?");
city = city.toUpperCase();


if ((city === ("")) || (city === (" "))){
msg = ("No City entered. Unable to determine delivery availability.");



}



else {

switch(city){

case "DES MOINES": 
	msg = ("Delivery will occur in 3 days.");
	break;
case "KANSAS CITY":
	msg = ("Deliver will occur in 1 week.");
	break;
case "DENVER":
	msg = ("Deliver will occur in 2 week.");
	break;
case "MIAMI":
	msg = ("Deliver will occur in 2 week.");
	break;
default : 
	msg = ("Sorry! Delivery is not available for your city yet.");

}


}

document.write(msg);

//--------------------------------------------------------------------------------------

var items = (0);

items = window.prompt("How many items do you want to order?");

if (items === 0){




}

else{

	document.write("<p>We can deliver up to " + items + " items to your city.</p>");
	document.write("<p>Print this out, write your item numbers below, and mail it to us to order.</p>");


}


for (let count = 1; count <= items; count ++) {

document.write(count + "<p>_-_-_-_-_-_-_-_-_</p>");


}







