function computer (speed,hd,ram){
    this.speed=speed;
    this.hd=hd;
    this.ram=ram;

}

var computer1 = new computer ("10GHZ","2TB","32GB");

document.write("Computer Speed: " + computer1.speed + "<br>");
document.write("Computer Hard Disk: " + computer1.hd + "<br>");
document.write("Computer RAM: " + computer1.ram + "<br>");





