function convertTemp() {
    const celsius = parseFloat(document.getElementById("celsius").value);
    const fahrenheit = (celsius * 1.8) + 32;
    const kelvin = celsius + 273.15;
  
    document.getElementById("fahrenheitResult").innerHTML = "The temperature in Fahrenheit is: " + fahrenheit.toFixed(2) + "F";
    document.getElementById("celsiusResult").innerHTML = "The temperature in Celsius is: " + celsius.toFixed(2) + "C";
    document.getElementById("kelvinResult").innerHTML = "The temperature in Kelvin is: " + kelvin.toFixed(2) + "K";
  }
  



 