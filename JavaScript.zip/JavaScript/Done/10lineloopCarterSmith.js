for (let count = 1; count <11; count++)

{

	document.write(count + "<br>");

}


document.write("---------------------------------------------------- <br>");

document.write("T - <br>");

let countt = 10;

while (countt >= 1){

document.write(countt + "<br>");
countt--;


}



document.write("---------------------------------------------------- <br>");

let counttt = 5;
do{

document.write(counttt + "<br>");
counttt += 5;


} while (counttt < 101);