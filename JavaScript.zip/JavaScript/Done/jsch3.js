var headingText = "<h1>A page of JavaScript</h1>";
var myIntro = "Hello, Welcome to my Javascript page!";
var linkTag = "<a href=\"http://www.iowacentral.edu\"> Link to a Site</a>";
var redText = "<span style=\"color:red\"> I am so colorful today!</span>";
var blueText = "<span style=\"color:blue\"> Spelling is important to avoid errors!</span>";
var beginEffect2 = "<em>";
var endEffect2 = "</em>";
var beginEffect = "<strong>";
var endEffect = "</strong>";
var beginPara = "<p>";
var endPara = "</p>";
var beginCenter = "<center>";
var endCenter = "</center>";



document.write(beginCenter + headingText + endCenter);
document.write(beginEffect + myIntro + endEffect);
document.write(beginPara + beginEffect2 + blueText + endEffect2 + endPara);
document.write(beginPara + linkTag + endPara);
document.write(beginPara + redText + endPara);

