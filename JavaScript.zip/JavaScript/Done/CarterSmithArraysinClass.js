var i = 0;
var arr = [];



i = window.prompt("What is the student's test scorce? When done enter -1.");


while(i >= 0){


arr.push(i);

i = window.prompt("What is the student's test scorce? When done enter -1.");


}

document.write("<p>Students Test Scores:</p>");

var total = 0
var studentAmount = arr.length;

for( let testprint = 0; testprint < studentAmount; testprint++)
{
	var score = parseInt(arr.pop());
	document.write("Test Score is: " + score + "<br>");
	total += score;
}

	
averageTest = (total/studentAmount);

document.write("Average test score:" + averageTest);