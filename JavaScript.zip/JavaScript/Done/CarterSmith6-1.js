var msg = ("");

var city = window.prompt("What is the name of your city?");
city = city.toUpperCase();


if ((city === ("")) || (city === (" "))){
msg = ("No City entered. Unable to determine delivery availability.");



}



else {

switch(city){

case "DES MOINES": 
	msg = ("Delivery will occur in 3 days.");
	break;
case "KANSAS CITY":
	msg = ("Deliver will occur in 1 week.");
	break;
case "DENVER":
	msg = ("Deliver will occur in 2 week.");
	break;
case "MIAMI":
	msg = ("Deliver will occur in 2 week.");
	break;
default : 
	msg = ("Sorry! Delivery is not available for your city yet.");

}


}

document.write(msg);