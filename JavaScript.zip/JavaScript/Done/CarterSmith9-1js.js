var titleAtt = document.getElementById("div1").getAttribute("title");

window.alert(titleAtt);

var newDiv = document.createElement("div2");

newDiv.textContent = "See you!";
newDiv.setAttribute("title","Lucky!");

var div1 = document.getElementById("div1");
div1.appendChild(newDiv);

document.write("<br>" + "Last Updated: " + document.lastModified);