let computerParts = ["Monitors","Motherboards","Chips","Hard Drives","Chips","Hard Drives",
"DVD-Roms","Ram","Cooling Fans","Cases","Power Supplies","Video Boards"];

var length = computerParts.length;




for (let i = 0; i < length; i++) {



	document.write(computerParts[i] + "<br>");


}