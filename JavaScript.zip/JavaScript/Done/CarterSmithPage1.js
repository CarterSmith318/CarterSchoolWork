function calculateMPG() {
    const miles = parseFloat(document.getElementById("miles").value);
    const gallons = parseFloat(document.getElementById("gallons").value);
    const mpg = miles / gallons;
    document.getElementById("mpgResult").innerHTML = "Your MPG is: " + mpg.toFixed(2);
  }
  