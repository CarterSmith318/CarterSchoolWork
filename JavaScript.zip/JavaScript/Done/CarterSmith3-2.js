var theHeading = "<h1>Welcome to Carter's Web Page!</h1>";
linkTag = "<a href=\http://www.iowacentral.edu\>Web Site Link!</a>";
someText = "This text can be changed by other statements.";
beginEffect = "<em>";
endEffect = "</em>";
beginPara = "<p>";
endPara = "</p>";
beginEffect2 = "<strong>";
endEffect2 = "</strong>";



document.write(theHeading);
document.write(beginEffect + someText + endEffect);
document.write(beginPara + linkTag + endPara);
document.write(beginPara + someText + endPara);
document.write(beginPara + beginEffect2 + someText + endEffect2 + endPara);
var greenText = "<span style=\"color:green\"> This text can be changed by other statements.</span>";
document.write(greenText);
