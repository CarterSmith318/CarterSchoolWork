// Get the pn and reminder 
const pnInput = document.getElementById("pn");
const reminderSpan = document.getElementById("reminder");
// get adress
const adressInput = document.getElementById("address");
const reminderSpan2 = document.getElementById("reminder2");

// Add event listener 
pnInput.addEventListener("focus", function() {
    // When pn receives focus, change the innerHTML of rm to the text
    reminderSpan.innerHTML = "Phone Number Format: (123) 456-7890";
});

pnInput.addEventListener("blur", function() {
    // When pn is blurred, change the innerHTML of rm to an empty string
    reminderSpan.innerHTML = "";
});


adressInput.addEventListener("focus", function() {

    reminderSpan2.innerHTML = "Number, Street, City, County, State";

});

adressInput.addEventListener("blur", function(){

    reminderSpan2.innerHTML = "";


});
