function displayTime() {
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    var amOrPm = hour >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour time
    hour = hour % 12;
    hour = hour ? hour : 12;
    
    // Add leading zeros to minutes and seconds
    minute = checkTime(minute);
    second = checkTime(second);
    
    // Get day of the week, month, and date
    var daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var dayOfWeek = daysOfWeek[now.getDay()];
    var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var month = months[now.getMonth()];
    var date = now.getDate();
    var year = now.getFullYear();
    
    // Update the clock
    var timeString = hour + ':' + minute + ':' + second + ' ' + amOrPm + ' ' + dayOfWeek + ', ' + month + ' ' + date + ', ' + year;
    document.getElementById('myClock').innerHTML = timeString;
  }
  
  function checkTime(time) {
    if (time < 10) {
      time = '0' + time;
    }
    return time;
  }
  
  // Call the displayTime function every second
  setInterval(displayTime, 1000);
  