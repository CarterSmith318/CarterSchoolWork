function calculateTotal() {
    const hotdog = parseInt(document.querySelector('#hotdog').value) || 0;
    const hamburger = parseInt(document.querySelector('#hamburger').value) || 0;
    const porkchop = parseInt(document.querySelector('#porkchop').value) || 0;
    const popcorn = parseInt(document.querySelector('#popcorn').value) || 0;
    const candy = parseInt(document.querySelector('#candy').value) || 0;
    const water = parseInt(document.querySelector('#water').value) || 0;
    const soda = parseInt(document.querySelector('#soda').value) || 0;

    const total = (hotdog * 1.00) + (hamburger * 3.00) + (porkchop * 4.00) + (popcorn * 1.00) + (candy * 1.50) + (water * 3.00) + (soda * 3.00);

    document.querySelector('#total-price').textContent = `$${total.toFixed(2)}`;
}
