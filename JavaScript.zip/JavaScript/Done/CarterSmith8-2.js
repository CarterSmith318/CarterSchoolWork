function computer(type,processor,ram,hd){
this.type=type;
this.processor=processor;
this.ram=ram;
this.hd=hd;

}


computer.prototype.describe = function() {

document.write(this.type + ": " + this.processor + ", " + this.ram + ", " + this.hd + "<br>");

}


var workComputer = new computer("Work","1.5GHZ","4GB","250GB");

var homeComputer = new computer("Home","2GHZ","8GB","1TB");

var gamingComputer = new computer("Gaming", "8GHZ","32GB","30TB");

workComputer.describe();
homeComputer.describe();
gamingComputer.describe();