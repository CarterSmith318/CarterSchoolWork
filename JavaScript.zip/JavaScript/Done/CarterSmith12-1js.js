let links = [
    "https://www.google.com",
    "https://www.yahoo.com",
    "https://www.iowacentral.edu",
    "https://www.https://www.humboldt.k12.ia.us",
    "https://www.youtube.com"
  ];
  
  let randomIndex = Math.floor(Math.random() * 5);
  
  let randomLinkDiv = document.getElementById("randomLink");
  let randomLink = document.createElement("a");
  randomLink.href = links[randomIndex];
  randomLink.innerHTML = "Random Site!";
  randomLinkDiv.innerHTML = "";
  randomLinkDiv.appendChild(randomLink);
  