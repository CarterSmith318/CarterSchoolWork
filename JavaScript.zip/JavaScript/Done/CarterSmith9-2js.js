document.getElementById("cLink").addEventListener("click", function(event) {
    event.preventDefault();
    document.getElementById("div1").style.backgroundColor = "#fe584c";
    document.getElementById("div1").innerHTML = "<strong>Right now!</strong> Was that quick or what?";
  });

  document.write("<br>" + "Last Updated: " + document.lastModified);