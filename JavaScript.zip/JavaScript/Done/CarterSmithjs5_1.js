var paycheck = 2500
var extraMoney = 2000
var damages = 1000
var fin = (paycheck + extraMoney - damages) * 2
var p = "<p>";
var ep = "</p>";
document.write(p + "Your inital paycheck is $" + paycheck + ep)
document.write(p + "Your paycheck plus commision is $" + (paycheck + extraMoney) + ep)
document.write(p + "Your paycheck minus penalties is $" + (paycheck + extraMoney - damages) + ep)
document.write(p + "Your final paycheck x 2 is $" + fin + ep)





