const messages = ["Dogs","Xbox","Tech","Coca-Cola","Science","Pizza","Security Work","Star Trek","Docture Who", "Star Wars", "PS5","Hot Chocolate","Bob's Burgers", "Cheese Burgers", "Steak", "TV","High Speed Internet","Lord of the Rings","Weight Lifting","Gold","Rudies","Dragons","CAT-6 Cable","Hell Cat","French Fries", "Brave Little Toaster","French Toast","Waffels","USB-C","JavaScript","HTML","Python","C++","Cards"];

function showMessage() {
  const randomIndex = Math.floor(Math.random() * messages.length);
  const message = messages[randomIndex];
  const messageElement = document.getElementById("message");
  messageElement.textContent = message;
}
