package Lab11CarterSmith;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Lab11CarterSmith {

    public static void main(String[] args) {
        String inputFile = "names.dat";  // Input file name
        String outputFile = "initials.dat";      // Output file name

        // Try-with-resources to handle file operations
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            processFile(reader, writer); // Process each line of the file

        } catch (IOException e) {
            // Handle any IOExceptions, like file not found
            System.err.println("Error handling file: " + e.getMessage());
        }
    }

    // Processes the file line by line
    private static void processFile(BufferedReader reader, BufferedWriter writer) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            try {
                String initials = extractInitials(line); // Extract initials from the line
                writer.write(initials);                 // Write initials to output file
                writer.newLine();
            } catch (IllegalArgumentException e) {
                // Handle invalid input format
                System.err.println("Invalid input format: '" + line + "'");
            }
        }
    }

    // Extracts initials from a single line
    private static String extractInitials(String nameLine) {
        // Validate input line
        if (nameLine == null || nameLine.trim().isEmpty()) {
            throw new IllegalArgumentException("Invalid name line");
        }

        String[] nameParts = nameLine.trim().split("\\s+"); // Split name into parts
        StringBuilder initials = new StringBuilder();

        // Iterate over each part to extract the first letter
        for (String part : nameParts) {
            if (!part.isEmpty()) {
                for (char ch : part.toCharArray()) {
                    if (Character.isLetter(ch)) {
                        initials.append(ch); // Append first alphabetic char
                        break;
                    }
                }
            }
        }

        // Check if any initials were found
        if (initials.length() == 0) {
            throw new IllegalArgumentException("No initials found in name line");
        }

        return initials.toString();
    }
}
