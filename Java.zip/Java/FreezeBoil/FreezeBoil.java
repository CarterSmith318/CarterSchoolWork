package FreezeBoil;

public class FreezeBoil {

    public static void main(String[] args) 
    {
        final double FreezingPoint = 32.0;
        final double BoilingPoint = 212.0;  
        double aveTemp; 

        System.out.print("water freezes at " + FreezingPoint);
        System.out.println(" and boils at " + BoilingPoint + " degrees.");

        aveTemp = FreezingPoint + BoilingPoint;
        aveTemp = aveTemp / 2.0;
        
        System.out.println("Halfway between these temperatures is " + aveTemp);
    } 
}
