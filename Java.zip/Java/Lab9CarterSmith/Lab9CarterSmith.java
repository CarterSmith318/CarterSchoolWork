package Lab9CarterSmith;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Lab9CarterSmith {

    public static void main(String[] args) {
        List<Integer> songTimes = readSongTimes("songs.dat");

        if (songTimes != null) {
            printTable(songTimes);
        } else {
            System.out.println("Error reading song data. Please check the file and try again.");
        }
    }

    // Reads song times from .dat file and returns representing song durations in seconds.
    private static List<Integer> readSongTimes(String fileName) {
        List<Integer> songTimes = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    int seconds = Integer.parseInt(line);
                    songTimes.add(seconds);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid data format in the file. Please make sure all entries are valid integers.");
                    return null;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the file. Make sure the file exists and is accessible.");
            return null;
        }

        return songTimes;
    }

    // Prints a table of songs and remaining time on the Cd
    private static void printTable(List<Integer> songTimes) {
        int totalMinutes = 80;
        int totalSeconds = totalMinutes * 60;

        System.out.printf("%-13s%-13s%-13s%-13s%-13s%n", "Track Number", "Minutes", "Seconds", "Total Minutes", "Total Seconds");
        System.out.println("-------------------------------------------------------------");

        int remainingTime = totalSeconds;
        int cumulativeMinutes = 0;
        int cumulativeSeconds = 0;

        if (songTimes.isEmpty()) {
            System.out.println("No song data found in the file.");
            return;
        }

        for (int i = 0; i < songTimes.size(); i++) {
            int songSeconds = songTimes.get(i);
            int songMinutes = songSeconds / 60;
            int songRemainingSeconds = songSeconds % 60;

            remainingTime -= songSeconds;
            if (remainingTime < 0) {
                System.out.println("Not enough space on the CD to fit all the songs.");
                return;
            }

            cumulativeMinutes += songMinutes;
            cumulativeSeconds += songRemainingSeconds;

            // Adjust total minutes and total seconds for carry-over
            cumulativeMinutes += cumulativeSeconds / 60;
            cumulativeSeconds %= 60;

            System.out.printf("%-13d%-13d%-13d%-13d%-13d%n", i + 1, songMinutes, songRemainingSeconds, cumulativeMinutes, cumulativeSeconds);
        }

        int remainingMinutes = remainingTime / 60;

        System.out.printf("%nThere are %d minutes and %d seconds of space left on the 80-minute CD.%n", remainingMinutes, remainingTime % 60);
    }
}

