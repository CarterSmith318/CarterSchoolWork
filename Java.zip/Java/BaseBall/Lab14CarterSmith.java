package BaseBall;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab14CarterSmith {

    public static void main(String[] args) {
        // Constants
        final int NUM_PLAYERS = 20;
        int[] hits = new int[NUM_PLAYERS];
        int[] atBats = new int[NUM_PLAYERS];
        int[] walks = new int[NUM_PLAYERS];

        // Read data file
        try {
            File file = new File("rawstats.dat");
            Scanner scanner = new Scanner(file);
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] tokens = line.split(" ");
                
                int playerID = Integer.parseInt(tokens[0]) - 1; // Adjust for array index
                hits[playerID] += Integer.parseInt(tokens[1]);
                walks[playerID] += Integer.parseInt(tokens[2]);
                atBats[playerID] += Integer.parseInt(tokens[1]) + Integer.parseInt(tokens[3]);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
            return;
        }

        // Calculate and print batting averages and walks
        System.out.printf("%-10s %-10s %-10s%n", "Player ID", "Walks", "Batting Avg");
        for (int i = 0; i < NUM_PLAYERS; i++) {
            double battingAvg = atBats[i] == 0 ? 0 : (double) hits[i] / atBats[i];
            System.out.printf("%-10d %-10d %-10.3f%n", i + 1, walks[i], battingAvg);
        }
    }
}
