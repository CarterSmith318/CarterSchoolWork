package Lab13CarterSmith;

import java.util.Scanner;
import java.util.Random;

public class Lab13CarterSmith {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int wins = 0;
        int losses = 0;
        boolean playAgain;

        do {
            int numberToGuess = random.nextInt(100) + 1;
            boolean hasWon = false;
            System.out.println("Guess a number between 1 and 100.");

            for (int attempts = 1; attempts <= 20; attempts++) {
                System.out.print("Attempt " + attempts + ": ");
                int guess = scanner.nextInt();

                if (guess == numberToGuess) {
                    hasWon = true;
                    wins++;
                    outputRandomMessage("win", random);
                    break;
                } else if (guess < numberToGuess) {
                    System.out.println("Too low!");
                } else {
                    System.out.println("Too high!");
                }
            }

            if (!hasWon) {
                losses++;
                outputRandomMessage("lose", random);
            }

            System.out.println("Do you want to play again? (yes/no)");
            playAgain = scanner.next().equalsIgnoreCase("yes");
        } while (playAgain);

        System.out.println("Total Wins: " + wins + ", Total Losses: " + losses);
        scanner.close();
    }

    private static void outputRandomMessage(String type, Random random) {
        switch (type) {
            case "win":
                switch (random.nextInt(10)) {
                    case 0: System.out.println("Incredible! You nailed it!"); break;
                    case 1: System.out.println("Fantastic! Right on target!"); break;
                    case 2: System.out.println("Great job! You guessed it!"); break;
                    case 3: System.out.println("Excellent! You're a mind reader!"); break;
                    case 4: System.out.println("Astounding! Exactly right!"); break;
                    case 5: System.out.println("Bravo! You've done it!"); break;
                    case 6: System.out.println("Remarkable! Spot on guess!"); break;
                    case 7: System.out.println("Impressive! You hit the mark!"); break;
                    case 8: System.out.println("Awesome! Correct guess!"); break;
                    case 9: System.out.println("Wonderful! You guessed correctly!"); break;
                }
                break;
            case "lose":
                switch (random.nextInt(10)) {
                    case 0: System.out.println("Oh snap! Just missed it!"); break;
                    case 1: System.out.println("Unlucky! Better luck next time!"); break;
                    case 2: System.out.println("So close! Try again!"); break;
                    case 3: System.out.println("Not this time! Keep trying!"); break;
                    case 4: System.out.println("Almost had it! Give it another go!"); break;
                    case 5: System.out.println("Tough luck! Don't give up!"); break;
                    case 6: System.out.println("Nice try! But not quite!"); break;
                    case 7: System.out.println("Missed it by that much! Try again!"); break;
                    case 8: System.out.println("Not quite right! You can do it!"); break;
                    case 9: System.out.println("Nope, that's not it! Have another go!"); break;
                }
                break;
        }
    }
}
