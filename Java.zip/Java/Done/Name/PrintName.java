package Name;

import java.util.Scanner;

public class PrintName {

    private static Name getName() {
        String first;
        String last;
        String middle;

        Scanner in = new Scanner(System.in);

        System.out.println("Enter first name: ");
        first = in.nextLine();
        System.out.println("Enter middle name: ");
        middle = in.nextLine();
        System.out.println("Enter last name: ");
        last = in.nextLine();

        in.close();

        // Create a new Name object using the constructor with input values
        return new Name(first, last, middle);
    }

    public static void main(String[] args) {
        // Get a Name object by calling the getName method
        Name myName = getName();

        // Print the name in the "first-middle-last" format
        System.out.println("Name in first-middle-last format: " +
                myName.getFirstName() + " " +
                myName.getMiddleName() + " " +
                myName.getLastName());
    }
}
