package Name;

public class Name {
    
    String first;
    String last;
    String middle;

    // Default constructor
    public Name() {
        first = "";
        last = "";
        middle = "";
    }

    // Constructor
    public Name(String firstName, String lastName, String middleName) {
        first = firstName;
        last = lastName;
        middle = middleName;
    }

    // Observer methods
    public String getFirstName() {
        return first;
    }

    public String getMiddleName() {
        return middle;
    }

    public String getLastName() {
        return last;
    }
}
