import java.util.Scanner;

public class CarterSmithLab1 {
    public static void main(String[] args) {
        String trunk = ""; // Initialize the trunk as an empty string
        Scanner scanner = new Scanner(System.in);

        // Simulate five turns in the game
        for (int i = 1; i <= 5; i++) {
            // Read and concatenate a new word or phrase to the existing trunk
            // You can replace the input statements with your own logic to get the words/phrases
            System.out.println("What did you pack in G-ma's trunk?");
            String newItem = scanner.nextLine(); // Replace this with your own words to get the new item
            trunk += newItem + " ";

            // Print the result
            System.out.println("In my grandmother's trunk, I packed: " + trunk);
        }

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}
