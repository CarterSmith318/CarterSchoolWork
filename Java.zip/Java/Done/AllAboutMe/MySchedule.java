package AllAboutMe;

public class MySchedule {
    public static void main(String[] args) {
        System.out.println("Carter Smith");
        System.out.println("Java w/ Scott: ");
        System.out.println("@ 8:20 Am to 9:20 Am");
        System.out.println("Data Structures w/ David: ");
        System.out.println("@ 9:30 Am to 10:30 Am");
        System.out.println("Programming w/ David:");
        System.out.println("@ 1:15 Pm to 2:15 Pm");
}
}
