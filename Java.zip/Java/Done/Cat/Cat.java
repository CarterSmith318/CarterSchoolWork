package Done.Cat;

public class Cat 
{

    String name;
    String color;
    float weight;

    // Default constructor
    public Cat() 
    {
        name = "";
        color = "";
        weight = 0;
    }

    // Constructor
    public Cat(String newName, String newColor, float newWeight) 
    {
        name = newName;
        color = newColor;
        weight = newWeight;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getColor()
    {
        return color;
    }
    
    public float getWeight()
    {
        return weight;
    }



}
