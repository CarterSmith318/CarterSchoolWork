package Done.Cat;

import java.util.Scanner;

public class CatDriver {
    
    static Scanner in = new Scanner(System.in);
     
    public static void main(String[] args) 
    {
        System.out.println("Enter the name of the cat: ");
        String catName = in.nextLine();
        System.out.println("Enter the color of the cat: ");
        String catColor = in.nextLine();
        System.out.println("Enter the weight of the cat: ");
        float catWeight = in.nextFloat();

        Cat myCat = new Cat(catName, catColor, catWeight);

        System.out.println("The cat's name is " + myCat.getName());
        System.out.println("The cat's color is " + myCat.getColor());
        System.out.println("The cat's weight is " + myCat.getWeight());

        in.close();

    }

    
}
