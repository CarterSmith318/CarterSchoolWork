package ExamQuestionsCarterSmith;

public class ExamQuestionsCarterSmithTestDriver {

    public static void main(String[] args) {
        // Using the default constructor
        ExamQuestionsCarterSmith question1 = new ExamQuestionsCarterSmith();

        // Setting values using the parameterized constructor
        ExamQuestionsCarterSmith question2 = new ExamQuestionsCarterSmith(
                "What is the capital of France?",
                "A. London",
                "B. Paris",
                "C. Berlin",
                "D. Madrid",
                'B'
        );

        // Accessing and printing the details of the first question
        System.out.println("Question 1: " + question1.getQuestion());
        System.out.println("Answer A: " + question1.getAnswerA());
        System.out.println("Answer B: " + question1.getAnswerB());
        System.out.println("Answer C: " + question1.getAnswerC());
        System.out.println("Answer D: " + question1.getAnswerD());
        System.out.println("Correct Answer: " + question1.getCorrectAnswer());
        System.out.println();

        // Accessing and printing the details of the second question
        System.out.println("Question 2: " + question2.getQuestion());
        System.out.println("Answer A: " + question2.getAnswerA());
        System.out.println("Answer B: " + question2.getAnswerB());
        System.out.println("Answer C: " + question2.getAnswerC());
        System.out.println("Answer D: " + question2.getAnswerD());
        System.out.println("Correct Answer: " + question2.getCorrectAnswer());
    }
}
