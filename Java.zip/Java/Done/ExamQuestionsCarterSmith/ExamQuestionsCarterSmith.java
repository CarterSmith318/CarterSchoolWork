package ExamQuestionsCarterSmith;

public class ExamQuestionsCarterSmith 
{

    String question;
    String answerA;
    String answerB;
    String answerC;
    String answerD;
    char correctAnswer;

    // Default constructor
    public ExamQuestionsCarterSmith() 
    {
        question = "";
        answerA = "";
        answerB = "";
        answerC = "";
        answerD = "";
        correctAnswer = ' ';
    }

    // Constructor
    public ExamQuestionsCarterSmith(String newQuestion, String newAnswerA, String newAnswerB, String newAnswerC, String newAnswerD, char newCorrectAnswer) 
    {
        question = newQuestion;
        answerA = newAnswerA;
        answerB = newAnswerB;
        answerC = newAnswerC;
        answerD = newAnswerD;
        correctAnswer = newCorrectAnswer;
    }
    
    public String getQuestion()
    {
        return question;
    }
    
    public String getAnswerA()
    {
        return answerA;
    }

    public String getAnswerB()
    {
        return answerB;
    }

    public String getAnswerC()
    {
        return answerC;
    }

    public String getAnswerD()
    {
        return answerD;
    }

    public char getCorrectAnswer()
    {
        return correctAnswer;
    }
    



}
