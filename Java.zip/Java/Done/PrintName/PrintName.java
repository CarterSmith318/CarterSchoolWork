package PrintName;

import java.util.Scanner; // Import the Scanner class

public class PrintName {
    static final char COMMA = ','; // Constant variable
    static final char BLANK = ' '; // Constant variable

    public static void main (String[] args) {
    String title;
    String firstName;
    String lastName;
    String middleName;
    String firstLast; // First name and last name format
    String lastFirst; // Last name and first name format
    Scanner in;
    in = new Scanner(System.in);

    System.out.print("Enter your first name: ");
    firstName = in.nextLine();
    System.out.print("Enter your middle name: ");
    middleName = in.nextLine();
    System.out.print("Enter your last name: ");  
    lastName = in.nextLine();
    System.out.print("Enter your title: ");
    title = in.nextLine();

    in.close(); // Close the scanner
       
       firstLast = title + BLANK + firstName + BLANK + middleName + BLANK + lastName;
       lastFirst = lastName + COMMA + BLANK + title + BLANK + firstName + BLANK + middleName;

       System.out.println("Name in first, last format is " + firstLast);
       System.out.println("Name in last, first format is " + lastFirst);
    

    }
    
}
