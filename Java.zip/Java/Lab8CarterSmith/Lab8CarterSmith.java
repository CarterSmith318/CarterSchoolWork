package Lab8CarterSmith;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Lab8CarterSmith {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Use a sentinel value to end processing
        while (true) {
            try {
                // Prompt user for input
                System.out.print("Enter an integer larger than 1 (or 'q' to exit): ");
                String inputString = scanner.next();

                // Check for sentinel value
                if (inputString.equalsIgnoreCase("q")) {
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                }

                int input = Integer.parseInt(inputString);

                // Validate input
                if (input <= 1) {
                    System.out.println("Please enter an integer larger than 1.");
                    continue;
                }

                // Calculate the sum of squares
                int sum = 0;
                for (int i = 1; i <= input; i++) {
                    sum += i * i;
                }

                // Display the result
                System.out.println("For the integer " + input + ", the sum of squares is: " + sum);
            } catch (NumberFormatException | InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer or 'q' to exit.");
                scanner.nextLine(); // Clear the input buffer
            }
        }

        // Close the scanner
        scanner.close();
    }
}
