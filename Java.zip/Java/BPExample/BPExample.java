package BPExample;

import java.io.*;
import java.util.Scanner;

public class BPExample 
{
    public static void main(String[] args) throws IOException
    {
        
        Scanner in = new Scanner(new FileReader("BP.dat"));
        int thisBP;
        System.out.println("Blood Pressures on file BP.dat: ");

        boolean flag = in.hasNextInt();


        while (flag)
        {
            thisBP = in.nextInt();
            flag = in.hasNextInt();
            if (thisBP < 200)
            {
                System.out.println(thisBP + " ");
            }
            else 
            {
                System.out.println("Warning: BP at 200 or above: " + thisBP);
            }
            
        }

        System.out.println();
        in.close();




    }
    
}
