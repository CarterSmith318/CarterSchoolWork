package BoolenOutputDemo;

import java.util.Scanner;

public class BoolenOutputDemo 

{

    public static void main(String[] args) 
    {
        boolean answer;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter 1 if you think the sun travels east to west.");
        System.out.println("Enter 2 if you think the sun travels west to east.");

        int response = in.nextInt();
        answer = (response == 1);
        System.out.println("Your answer is " + answer + ".");
        in.close();
    }
    
}
