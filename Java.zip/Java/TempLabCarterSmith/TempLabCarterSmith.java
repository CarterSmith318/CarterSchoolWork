package TempLabCarterSmith;

import java.util.Scanner;

public class TempLabCarterSmith {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the temperature in Celsius: ");
        int celsius = scanner.nextInt();

        double fahrenheit = ((celsius * (9.0 / 5.0))) + 32;

        System.out.println("Celsius temperature: " + celsius);
        System.out.println("Fahrenheit temperature: " + fahrenheit);

        scanner.close();
    }
}
