package FileIOExample;

import java.io.*;
import java.util.Scanner;

public class FileIOExample
{

    public static void main(String[] args) throws IOException
    {
        String inString;

        PrintWriter out = new PrintWriter(new FileWriter("outFile.dat"));
        out.println("Successsfuly opened file outFile.dat");
        out.println();
        out.println("String from Scanner Object: ");

        Scanner in = new Scanner(new FileReader("inFile.dat"));

        if(in.hasNextLine())
        {
            inString = in.nextLine();
            
        }
        else
        {
            inString = "The file is empty";
        }

        out.println(inString);


        in.close();
        out.close();

    }

}