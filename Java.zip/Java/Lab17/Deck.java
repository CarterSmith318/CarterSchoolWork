package Lab17;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> cards;

    public Deck(boolean fill) {
        cards = new ArrayList<>();
        if (fill) {
            for (String suit : new String[]{"Hearts", "Clubs", "Diamonds", "Spades"}) {
                for (int rank = 1; rank <= 13; rank++) {
                    cards.add(new Card(rank, suit));
                }
            }
        }
    }

    public void add(Card card) { 
        cards.add(card);
    }

    public Card remove() {
        return cards.size() > 0 ? cards.remove(cards.size() - 1) : null; // if else statement first part is true remove card else deck is empty
    }

    public void shuffle() {
        Collections.shuffle(cards);
    }

    @Override
    public String toString() {
        return cards.toString();
    }
}
