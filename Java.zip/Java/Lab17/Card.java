package Lab17;



public class Card implements Comparable<Card> {
    private final int rank;
    private final String suit;

    public Card(int rank, String suit) {
        this.rank = rank;
        this.suit = suit;
    }

    public int getRank() {
        return rank;
    }

    public String getSuit() {
        return suit;
    }

    @Override
    public int compareTo(Card other) {
        if (this.rank != other.rank) {
            return Integer.compare(this.rank, other.rank);
        } else {
            return this.suitValue() - other.suitValue();
        }
    }

    private int suitValue() {
        switch (this.suit) {
            case "Spades": return 4;
            case "Diamonds": return 3;
            case "Clubs": return 2;
            case "Hearts": return 1;
            default: return 0;
        }
    }

    @Override
    public String toString() {
        String[] ranks = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        return ranks[this.rank - 1] + " of " + this.suit;
    }
}

