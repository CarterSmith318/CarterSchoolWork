package Lab17;

public class CarterSmithLab17 {
    public static void main(String[] args) {
        Deck deck = new Deck(true); // Initialize a deck with 52 cards
        deck.shuffle(); // Shuffle the deck

        // Displaying the initial setup for Solitaire
        System.out.println("Initial Solitaire setup:");
        for (int i = 0; i < 7; i++) {
            System.out.println("Pile " + (i + 1) + ":");
            for (int j = 0; j <= i; j++) {
                Card card = deck.remove();
                if (j == i) {
                    System.out.println("Card visible: " + card);
                } else {
                    System.out.println("Card hidden: " + card);
                }
            }
            System.out.println();
        }
    }
}
