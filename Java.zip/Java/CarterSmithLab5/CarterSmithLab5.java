package CarterSmithLab5;

import java.util.Scanner;

public class CarterSmithLab5 
{

    public static void main(String[] args) {
        float radius = 0.0f; // Initialize radius variable
        final float PI = 3.14159f; // Declare and initialize PI constant

        // Get radius input from user
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the radius: ");
        radius = scanner.nextFloat();
        scanner.close();
        
        
        // Calculate diameter, circumference, and area
        float diameter = 2 * radius;
        float circumference = 2 * PI * radius;
        float area = PI * radius * radius;

        // Output the results
        System.out.println("Radius: " + radius);
        System.out.println("Diameter: " + diameter);
        System.out.println("Circumference: " + circumference);
        System.out.println("Area: " + area);
    }
    
    
}
