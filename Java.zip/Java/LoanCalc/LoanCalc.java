package LoanCalc;

import java.util.Scanner;

public class LoanCalc
{


    public static void main(String[] args)
    {
        //Declarations
        double loanAmount;
        double yearlyInterest;
        int numberOfYears;
        double monthlyIntrests;
        int numberOfPayments;
        double Payment;

    

        Scanner in = new Scanner(System.in);

        //Ask user for loan amount
        System.out.println("Enter the loan amount: ");
        loanAmount = in.nextDouble();

     //Ask user for yearly interest rate
        System.out.println("Enter the yearly interest rate: ");
        yearlyInterest = in.nextDouble();

        if (yearlyInterest >= 0.25)
        {
         yearlyInterest = yearlyInterest / 100.0;
        }

        //Ask user for number of years
        System.out.println("Enter the number of years: ");
        numberOfYears = in.nextInt();

        //Calculate monthly interest rate
        monthlyIntrests = yearlyInterest / 12.0;

        //Calculate number of payments
        numberOfPayments = numberOfYears * 12;

        //Calculate payment
        Payment = (loanAmount * monthlyIntrests) / (1 - Math.pow(1 + monthlyIntrests, -numberOfPayments));

        //Display payment
        System.out.println();
        System.out.println("For the intial loan amount of: $" + loanAmount);
        System.out.println("At the yearly interest rate of: " + yearlyInterest * 100 + "%");
        System.out.println("For the number of payments: " + numberOfPayments);
        System.out.println("The monthly payment is: " + Payment);
        
        in.close();
        
    }
} //End of class LoanCalc



