package CarterSmithLab7;

import java.util.Scanner;

public class CarteSmithLab7 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int year;

        do {
            // Prompt the user to enter the year (or -1 to exit)
            System.out.print("Enter the year (1982 to 2048, or -1 to exit): ");

            // Validate input to ensure it is an integer within the specified range
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid year.");
                System.out.print("Enter the year (1982 to 2048, or -1 to exit): ");
                scanner.next();  // Consume the invalid input
            }

            year = scanner.nextInt();

            if (year == -1) {
                // Exit the loop if -1 is entered
                break;
            } else if (year < 1982 || year > 2048) {
                // Inform the user about the valid range and continue the loop
                System.out.println("Invalid year. Please enter a year between 1982 and 2048.");
                continue;
            }

            // Calculate and display the Easter Sunday date for the entered year
            int[] easterDate = calculateEasterSunday(year);
            System.out.println(year + ": " + easterDate[0] + "/" + easterDate[1]);

        } while (true);

        System.out.println("Exiting the program.");
        scanner.close();
    }

    private static int[] calculateEasterSunday(int year) {
        // Calculate variables based on the provided formula
        int a = year % 19;
        int b = year % 4;
        int c = year % 7;
        int d = (19 * a + 24) % 30;
        int e = (2 * b + 4 * c + 6 * d + 5) % 7;
        int day = 22 + d + e;

        // Adjust the month and day if necessary
        int month;
        if (day > 31) {
            day -= 31;
            month = 4;
        } else {
            month = 3;
        }

        return new int[]{month, day};
    }
}
