package Lab18;

import java.util.Scanner;

public class CarterSmithLab18  {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter strings to check for palindromes (type 'exit' to quit):");

        while (true) {
            System.out.print("Input: ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("exit")) {
                break;
            }
            
            String normalized = normalize(input);
            boolean isPalindrome = isPalindrome(normalized, 0, normalized.length() - 1);
            System.out.println("\"" + input + "\" is " + (isPalindrome ? "" : "not ") + "a palindrome.");
        }

        scanner.close();
    }

    private static String normalize(String input) {
        return input.replaceAll("[^a-zA-Z]", "").toLowerCase();
    }

    private static boolean isPalindrome(String s, int left, int right) {
        if (left >= right) {
            return true;
        }
        if (s.charAt(left) != s.charAt(right)) {
            return false;
        }
        return isPalindrome(s, left + 1, right - 1);
    }
}
