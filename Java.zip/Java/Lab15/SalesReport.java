package Lab15;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SalesReport {
    static class SalesPerson {
        String name;
        int sales;
        float expenses;

        public SalesPerson(String name, int sales, float expenses) {
            this.name = name;
            this.sales = sales;
            this.expenses = expenses;
        }
    }

    public static void main(String[] args) {
        String fileName = "sales.dat";
        List<SalesPerson> salesPeople = new ArrayList<>();

        // Check if the file exists
        if (!Files.exists(Paths.get(fileName))) {
            System.err.println("Error: The file " + fileName + " does not exist.");
            return;
        }

        // Read data from the file
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String name = line.trim();
                if ((line = reader.readLine()) != null) {
                    try {
                        String[] numbers = line.trim().split("\\s+");
                        int sales = Integer.parseInt(numbers[0]);
                        float expenses = Float.parseFloat(numbers[1]);
                        salesPeople.add(new SalesPerson(name, sales, expenses));
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing numbers for " + name + ". Skipping...");
                        continue;
                    }
                } else {
                    System.err.println("Incomplete data for " + name + ". Expected sales and expenses.");
                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
            return;
        }

        // Proceed only if there are salespeople data
        if (salesPeople.isEmpty()) {
            System.err.println("No valid data to process.");
            return;
        }

        // Calculate totals
        int totalSales = salesPeople.stream().mapToInt(sp -> sp.sales).sum();
        double totalExpenses = salesPeople.stream().mapToDouble(sp -> sp.expenses).sum();

        // Print header
        System.out.printf("Total Sales: %d, Total Expenses: %.2f%n", totalSales, totalExpenses);
        System.out.println("Name\t\t% Total Sales\t% Total Expenses");

        // Sort, calculate percentages, and print data
        salesPeople.stream()
            .sorted(Comparator.comparing(sp -> sp.name.split(",")[0])) // Assuming name is "Last, First"
            .forEach(sp -> {
                double salesPercent = 100.0 * sp.sales / totalSales;
                double expensesPercent = 100.0 * sp.expenses / totalExpenses;
                System.out.printf("%s\t\t%.2f%%\t\t%.2f%%%n", sp.name, salesPercent, expensesPercent);
            });
    }
}
