import java.util.Scanner;
import java.util.Random;

public class RPSLab12CarterSmith {
    public static void main(String[] args) {
        // Scanner for user input
        Scanner scanner = new Scanner(System.in);
        // Random generator for computer's choice
        Random random = new Random();

        // Variables to keep track of wins, losses, and ties
        int wins = 0;
        int losses = 0;
        int ties = 0;

        while (true) {
            // Prompt user 
            System.out.println("Enter R for Rock, P for Paper, S for Scissors or Q to Quit:");
            String userInput = scanner.nextLine().toUpperCase();

            // Check if user wants to quit
            if (userInput.equals("Q")) {
                break;
            }

            // Validate user input (R, P, S)
            while (!(userInput.equals("R") || userInput.equals("P") || userInput.equals("S"))) {
                System.out.println("Invalid input. Please enter R, P, S, or Q to quit:");
                userInput = scanner.nextLine().toUpperCase();
            }

            // Generate computer's choice (1: Rock, 2: Paper, 3: Scissors)
            int computerChoice = random.nextInt(3) + 1;
            String computerMove = "";
            switch (computerChoice) {
                case 1:
                    computerMove = "R";
                    break;
                case 2:
                    computerMove = "P";
                    break;
                case 3:
                    computerMove = "S";
                    break;
            }

            // Display computer's choice
            System.out.println("Computer's choice: " + computerMove);

            // Determine the outcome of the game
            if (userInput.equals(computerMove)) {
                System.out.println("It's a tie!");
                ties++;
            } else if ((userInput.equals("R") && computerMove.equals("S")) ||
                       (userInput.equals("S") && computerMove.equals("P")) ||
                       (userInput.equals("P") && computerMove.equals("R"))) {
                System.out.println("You win!");
                wins++;
            } else {
                System.out.println("You lose!");
                losses++;
            }

            // Display current score
            System.out.println("Wins: " + wins + ", Losses: " + losses + ", Ties: " + ties);
        }

        // Close the scanner and end the game
        scanner.close();
        System.out.println("Game Over!");
    }
}
