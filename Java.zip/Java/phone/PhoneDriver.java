package phone;



public class PhoneDriver 
{
    
    public static void main(String[] args) throws Exception
    {
            Phone firstPhone;
            BusinessPhone secondPhone;

            System.out.println("Test results for class BusinessPhone:");

            firstPhone = new Phone(523, 373, 3322);
            secondPhone = new BusinessPhone(713, 233, 1234, 4321);

            System.out.println("getArea()" + firstPhone.getArea());
            System.out.println("getExchange()" + firstPhone.getExchange());
            System.out.println("getNumber()" + firstPhone.getNumber());
            System.out.println("toString()" + firstPhone.toString());

            System.out.println("getArea Bussiness" + secondPhone.getArea());
            System.out.println("getExchange Bussiness" + secondPhone.getExchange());
            System.out.println("getNumber Bussiness" + secondPhone.getNumber());
            System.out.println("getExtension Bussiness" + secondPhone.getExtension());

            System.out.println("toString Bussiness" + secondPhone.toString());


    }
    
}
