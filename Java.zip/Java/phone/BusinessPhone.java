package phone;

public class BusinessPhone extends Phone
{
 
    private int extension;

    public BusinessPhone()
    {
        super(); // Gets the default values from the Phone class
        extension = 9999;  // Sets the default value for the new field
    }

    public BusinessPhone(int Area, int Exch, int Num, int exten) throws Exception
    {
        super(Area, Exch, Num); // Calls the constructor of the superclass
        if (exten < 1000 || exten > 9999)
        {
            throw new Exception("Invalid extension: " + exten);
        }
        extension = exten;
    }

    public int getExtension() { return extension; }

    public String toString()
    {
        String str = super.toString();
        return (str + " x" + extension);
    }

}
