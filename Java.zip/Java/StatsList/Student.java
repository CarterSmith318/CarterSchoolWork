package StatsList;

public class Student implements Comparable<Student>
{

    String name;
    double grade;

    public Student(double newGrade, String newName)
    {
        name = newName;
        grade = newGrade;
    }

    public int compareTo(Student otherStudent)
    {
        Student anotherStudent = (Student) Student;
        if (grade < anotherStudent.grade)
        {
            return -1;
        }
        else if (grade > anotherStudent.grade)
        {
            return 1;
        }
        else 
        {
            return 0;
        }
    }

    public double getGrade()
    {
        return grade;
    }

    public String getName()
    {
        return name;
    }

    
}
