package StatsList;

import java.io.*;
import java.util.Scanner;

public class StatsDriver 
{

    public static void main(String[] args) throws IOException
    {
        StatsList stats;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the name of the file: ");
        String fileName = in.next();

        Scanner gradeFile = new Scanner(new FileReader(fileName));
        stats = new StatsList(gradeFile);

        System.out.println("The average grade is: " + stats.getAverage());
        System.out.println("Minimum grade is: " + stats.getMinGrade());
        System.out.println("The maximum grade is: " + stats.getMaxGrade());
        System.out.println("Number of grades above average: " + stats.getAboveAverage());
        System.out.println("Number of grades below average: " + stats.getBelowAverage());

        stats.studentMaxGrade();
        stats.studentsAbove();
        stats.studentsBelow();

        in.close();
    }
    
}
