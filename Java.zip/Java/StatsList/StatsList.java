package StatsList;
import java.util.Scanner;
import java.io.*;

public class StatsList 
{

    SortedListOfGrades list = new SortedListOfGrades();
    double average = 0.0;
    double maxGrade = 0.0;
    int numBelow = 0;
    
    public StatsList(Scanner gradeFile)
    {
        Student student;
        double sum = 0.0;
        double grade;
        String name;
        while (gradeFile.hasNext())
        {
            grade = gradeFile.nextDouble();
            name = gradeFile.nextLine();
            
            student = new Student(name, grade);
            list.add(student);
            sum = sum + grade;
            if (grade > maxGrade)
            {
                maxGrade = grade;
            }
        }

        average = sum / list.size();
        list.resetList();

        while (list.Next().getGrade() < average)
        {
            numBelow++;
        }
        
    }

    public double getAverage()
    {
        return average;
    }

    public double getMaxGrade()
    {
        return maxGrade;
    }

    public int getAboveAverage()
    {
        return (list.size() - numBelow);
    }

    public int getBelowAverage()
    {
        return numBelow;
    }

    public double getMinGrade()
    {
        list.resetList();
        return (list.next().getGrade());
    }


    public void studentMaxGrade()
    {
        list.resetList();
        Student item;
        item = list.next();
        while (maxGrade > item.getGrade())
        {
            item = list.next();
        }

        System.out.println("The fallowing student(s) had the maximum score: " );
        System.out.println(item.getName());

        while(list.hasNext())
        {
            System.out.println(list.next().getName());
        }
    }

    public void studentsAbove()
    {
        Student item;
        list.resetList();

        for (int count = 1; count <= numBelow; count++)
        {
            item = list.next();
        }

        System.out.println("The fallowing student(s) had a score above the average: ");
        for (int count = numBelow +1; count <= list.size(); count++)
        {
            System.out.println(list.next().getName());
        }
    }

    public void studentsBelow()
    {
        Student item;
        System.out.println("The fallowing student(s) had a score below the average: ");
        list.resetList();
        for (int count = 1; count <= numBelow; count++)
        {
            System.out.println(list.nest().getName());
        }
    }


}


