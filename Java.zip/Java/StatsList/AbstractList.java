package StatsList;

public abstract class AbstractList
{
    protected Comparable[] listItems;
    protected int numItems;
    protected int currentPos;

    public AbstractList()
    {
        numItems = 0;
        listItems = new Comparable[100];
        currentPos = 0;
    }

    public AbstractList(int maxItems)
    {
        numItems = 0;
        listItems = new Comparable[maxItems];
        currentPos = 0;
    }

    public boolean isFull()
    {
        return (listItems.length == numItems);
    }

    public boolean isEmpty()
    {
        return (numItems == 0);
    }

    public int size()
    {
        return numItems;
    }

    public abstract boolean contains (Comparable otherItem);

    public abstract void add (Comparable item);

    public abstract void remove (Comparable otherItem);

    public void resetList()
    {
        currentPos = 0;
    }

    public boolean hasNext()
    {
        return (currentPos < numItems);
    }

    public Comparable next()
    {
        Comparable next = listItems[currentPos];
        currentPos++;
        return next;
    }
}
