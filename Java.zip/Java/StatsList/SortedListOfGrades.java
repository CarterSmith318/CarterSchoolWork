package StatsList;

public class SortedListOfGrades extends AbstractList
{

    public SortedListOfGrades ()
    {
        super();
    }

    public SortedListOfGrades (int maxItems)
    {
        super(maxItems);
    }

    public boolean contains (Comparable otherItem)
    {

        Student item = (Student) otherItem;
        int index = 0;
        while (index < numItems && ((Student) listItems[index]).compareTo(item) > 0 )
        {
            index++;
        }

        return (index < numItems && ((Student) listItems[index]).compareTo(item) == 0);

    }

    public void add (Comparable itme)
    {
        if(!isFull())
        {
            int index = numItems -1;
            while (index >= 0 && (((Student)item).compareTo((Student)listItems[index]) < 0))
            {
                listItems[index + 1] = listItems[index];
                index--;
            }

            listItems[index + 1] = item;
            numItems++;
        }
    }

    public void remove(Comparable otherItem)
    {
        int index = 0;
        boolean found = false;

        Student item = (Student) otherItem;
        while (index < numItems && !found)
        {
            if (((Student)listItems[index]).compareTo(item) == 0)
            {
                found = true;
            }
            else
            {
                index++;
            }
        }

        if(found)
        {
            for (int count = index; count < numItems -1; count++)
            {
                listItems[count] = listItems[count + 1];
            }
            numItems--;
        }
    }
    
}
