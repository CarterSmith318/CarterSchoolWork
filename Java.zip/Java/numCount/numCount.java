package numCount;

import java.util.Scanner;
import java.util.Random;

public class numCount {

    public static void main(String[] args) {
        // Setup scanner and random number generator
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Variables to keep track of wins and losses
        int wins = 0;
        int losses = 0;
        boolean playAgain;

        do {
            // Generate a random number 
            int numberToGuess = random.nextInt(100) + 1;

            // Flag to check if the user has won in the current game
            boolean hasWon = false;
            System.out.println("Guess a number between 1 and 100.");

            // Loop for a maximum of 20 attempts
            for (int attempts = 1; attempts <= 20; attempts++) {
                System.out.print("Attempt " + attempts + ": ");
                // Error handling for non-integer inputs
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // discard the invalid input
                }
                int guess = scanner.nextInt();

                // Check if the guess is correct, too low, or too high
                if (guess == numberToGuess) {
                    hasWon = true;
                    wins++;
                    System.out.println("Correct! You won!");
                    break;
                } else if (guess < numberToGuess) {
                    System.out.println("Too low!");
                } else {
                    System.out.println("Too high!");
                }
            }

            if (!hasWon) {
                losses++;
                System.out.println("You lost! The correct number was " + numberToGuess + ".");
            }

            // Output a win or lose message based on the result
            outputRandomMessage(hasWon ? "win" : "lose");

            // Ask if the user wants to play again
            System.out.println("Do you want to play again? (yes/no)");
            // Error handling for incorrect yes/no inputs
            while (true) {
                String response = scanner.next();
                if (response.equalsIgnoreCase("yes")) {
                    playAgain = true;
                    break;
                } else if (response.equalsIgnoreCase("no")) {
                    playAgain = false;
                    break;
                } else {
                    System.out.println("Invalid response. Please answer with 'yes' or 'no'.");
                }
            }
        } while (playAgain); // Continue if the user wants to play again

        // Print total wins and losses when the user decides to quit
        System.out.println("Total Wins: " + wins + ", Total Losses: " + losses);
        scanner.close();
    }

    private static void outputRandomMessage(String type) {
        Random random = new Random();
        // Select and print a random message based on whether the user won or lost
        switch (type) {
            case "win":
                switch (random.nextInt(10)) {
                    case 0: System.out.println("Incredible! You're a natural!"); break;
                    
                    case 1: System.out.println("Good Job!"); break;
                    
                    case 2: System.out.println("Superb! You have a keen sense!"); break;
                }
                break;
            case "lose":
                switch (random.nextInt(10)) {
                    case 0: System.out.println("So close! You'll get it next time!"); break;
                    case 1: System.out.println("Not a Winner!"); break;
                    case 2: System.out.println("It was a tough one, wasn't it? Try again!"); break;
                }
                break;
        }
    }
}
