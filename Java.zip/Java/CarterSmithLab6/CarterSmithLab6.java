package CarterSmithLab6;

import java.util.Scanner;

public class CarterSmithLab6 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        char userChoice = 'Y';

        do {
            System.out.println("Enter a single letter: ");
            String input = scanner.nextLine().toUpperCase(); // Convert input to uppercase for case-insensitivity

            if (input.length() != 1 || !Character.isLetter(input.charAt(0))) {
                System.out.println("Invalid input. Please enter a single letter.");
                continue; // Continue to the next iteration of the loop
            }

            char letter = input.charAt(0);
            int digit = getDigit(letter);

            if (digit == -1) {
                System.out.println("Invalid input. The letter entered does not correspond to any digit.");
            } else {
                System.out.println("The digit corresponding to '" + letter + "' on a telephone is: " + digit);
            }

            System.out.println("Do you want to convert another letter? (Y/N): ");
            userChoice = scanner.nextLine().toUpperCase().charAt(0);

        } while (userChoice == 'Y');

        System.out.println("Exiting the program. Thank you!");
        scanner.close();
    }

    private static int getDigit(char letter) {
        switch (letter) {
            case '2':
            case 'A':
            case 'B':
            case 'C':
                return 2;
            case '3':
            case 'D':
            case 'E':
            case 'F':
                return 3;
            case '4':
            case 'G':
            case 'H':
            case 'I':
                return 4;
            case '5':
            case 'J':
            case 'K':
            case 'L':
                return 5;
            case '6':
            case 'M':
            case 'N':
            case 'O':
                return 6;
            case '7':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
                return 7;
            case '8':
            case 'T':
            case 'U':
            case 'V':
                return 8;
            case '9':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
                return 9;
            default:
                return -1; // Indicates invalid input
        }
    }
}
