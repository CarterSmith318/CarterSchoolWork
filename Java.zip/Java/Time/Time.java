package Time;

public class Time {
 double seconds;

    public Time() 
    {
        seconds = 0.0;
    }

    public Time(double newSeconds) 
    {
        seconds = newSeconds;
    }

    public Time(int hours, int minutes, double newSeconds) 
    {
        seconds = (double) (hours * 3600 + minutes * 60 + newSeconds);
    }

    public double getTime() 
    {
        return seconds;
    }

    public int getHours() 
    {
        return (int) (seconds / 3600);
    }

    public int getMinutes() 
    {
        return (int) (seconds % 3600 / 60);
    }

    public int getSeconds() 
    {
        return (int) (seconds % 60);
    }

    public String toString() 
    {
        int hours = (int) seconds / 3600;
        int minutes = (int) seconds % 3600 / 60;
        double roundedSeconds = (double) ((int) (seconds % 60 * 100 + 0.5)) / 100;
        return hours + ":" + minutes + ":" + roundedSeconds;


    }

    public Time plus(Time otherTime)
    {
        return new Time(seconds + otherTime.seconds);
    }

    public Time minus(Time otherTime)
    {
        return new Time(seconds - otherTime.seconds);
    }

}



