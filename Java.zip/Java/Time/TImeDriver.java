package Time;

public class TImeDriver {
    public static void main(String[] args) 
    {
        Time time1 = new Time();
        Time time2 = new Time(3845.123);
        Time time3 = new Time(8,2,5.5);
        System.out.println("Time 1-6");
        System.out.println("Created time1 = " + time1.getTime());
        System.out.println("Created time2 = " + time2.getTime());
        System.out.println("Created time3 = " + time3.getTime());

        System.out.println("Time 7-9");
        System.out.println("Time3 = " + time3.getHours() + "hours.");
        System.out.println("Time3 = " + time3.getMinutes() + "minutes.");
        System.out.println("Time3 = " + time3.getSeconds() + "seconds.");

        System.out.println();

        System.out.println("Test 10");
        System.out.println("Time2.plus(time3) = " + time2.plus(time3).getTime());

        System.out.println();

        System.out.println("Test 11");
        System.out.println("Time3.minus(time2) = " + time3.minus(time2).getTime());

        System.out.println();

        System.out.println("Test 12 - 14");
        System.out.println("USing to String");
        System.out.println("Time1 = " + time1);
        System.out.println("Time2 = " + time2);
        System.out.println("Time3 = " + time3);



    }
}
