package Lab16;

import java.io.*;
import java.util.*;

public class ShareholderCheck {
    public static void main(String[] args) {
        // Define the path to the shareholders' file
        String filename = "owner.dat";

        // Load the list of shareholders from the file
        Set<String> shareholders = loadShareholders(filename);

        // Create a scanner for keyboard input
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Ask the user to enter their name
            System.out.println("Please enter your first and last name to check attendance eligibility (enter -1 to exit):");

            // Read the name from the keyboard and convert to lowercase
            String name = scanner.nextLine().trim().toLowerCase();

            // Check if the input is -1 to exit
            if (name.equals("-1")) {
                System.out.println("Exiting program.");
                break;
            }

            // Check if the entered name is a shareholder
            if (shareholders.contains(name)) {
                System.out.println("You may attend the meeting.");
            } else {
                // If not found, give a second chance
                System.out.println("Name not recognized. Please try again.");
                System.out.println("Enter your first and last name exactly as registered:");

                // Read the name again and convert to lowercase
                name = scanner.nextLine().trim().toLowerCase();

                // Check for exit condition again
                if (name.equals("-1")) {
                    System.out.println("Exiting program.");
                    break;
                }

                if (shareholders.contains(name)) {
                    System.out.println("You may attend the meeting.");
                } else {
                    // If the second attempt fails, deny access
                    System.out.println("You may not participate in the meeting.");
                }
            }
        }

        scanner.close();
    }

    // Method to load shareholders from a file into a HashSet
    private static Set<String> loadShareholders(String filename) {
        Set<String> shareholders = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Convert each line to lowercase before adding to the set
                shareholders.add(line.trim().toLowerCase());
            }
        } catch (FileNotFoundException e) {
            System.out.println("The file " + filename + " was not found.");
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
        }
        return shareholders;
    }
}
