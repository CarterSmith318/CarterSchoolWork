import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CAL extends JFrame implements ActionListener {
    private JTextField display;
    private JButton[] numberButtons;
    private JButton addButton, subButton, equalButton;
    private double tempFirst = 0;
    private String operator = "";

    public CAL() {
        super("Calculator");
        setLayout(new BorderLayout());

        display = new JTextField();
        add(display, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 3));

        numberButtons = new JButton[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            buttonPanel.add(numberButtons[i]);
        }

        addButton = new JButton("+");
        subButton = new JButton("-");
        equalButton = new JButton("=");

        addButton.addActionListener(this);
        subButton.addActionListener(this);
        equalButton.addActionListener(this);

        buttonPanel.add(addButton);
        buttonPanel.add(subButton);
        buttonPanel.add(equalButton);

        add(buttonPanel, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(200, 300);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        for (int i = 0; i < 10; i++) {
            if (source == numberButtons[i]) {
                display.setText(display.getText() + i);
                return;
            }
        }

        if (source == addButton) {
            operator = "+";
            tempFirst = Double.parseDouble(display.getText());
            display.setText("");
        } else if (source == subButton) {
            operator = "-";
            tempFirst = Double.parseDouble(display.getText());
            display.setText("");
        } else if (source == equalButton) {
            double tempSecond = Double.parseDouble(display.getText());
            if ("+".equals(operator)) {
                display.setText((tempFirst + tempSecond) + "");
            } else if ("-".equals(operator)) {
                display.setText((tempFirst - tempSecond) + "");
            }
        }
    }

    public static void main(String[] args) {
        new CAL();
    }
}
