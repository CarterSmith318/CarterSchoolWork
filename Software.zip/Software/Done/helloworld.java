public class helloworld { //public must have same name as file name
    public static void main(String[] args) {
        System.out.println("Hello World! Hello World? Hello World.");
    }
}
