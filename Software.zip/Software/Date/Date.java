package Date;

import java.util.Scanner;

public class Date {
    private int year;
    private int month;
    private int day;
    private int julianDay;

    // Constructor for Gregorian date
    public Date(int year, int month, int day) {
        setYear(year);
        setMonth(month);
        setDay(day);
        this.julianDay = convertToJulianDate(year, month, day);
    }

    // Constructor for Julian date
    public Date(int julianDay) {
        convertToGregorianCalendar(julianDay); // Convert to Gregorian date
    }

    // Getter Methods
    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getJulianDay() {
        return julianDay;
    }

    // Setter Methods with Error-Checking
    public void setYear(int year) {
        if (year > 0) {
            this.year = year;
        } else {
            System.out.println("Invalid year value");
        }
    }

    public void setMonth(int month) {
        if (month >= 1 && month <= 12) {
            this.month = month;
        } else {
            System.out.println("Invalid month value");
        }
    }

    public void setDay(int day) {
        if (day >= 1 && day <= calculateDaysInMonth()) {
            this.day = day;
        } else {
            System.out.println("Invalid day value");
        }
    }

    // Calendar Switching Methods
    public void switchToJulianCalendar() {
        int julianDate = convertToJulianDate(year, month, day);
        System.out.println("Corresponding Julian Date: " + julianDate);
    }

    public void switchToGregorianCalendar() {
        convertToGregorianCalendar(julianDay);
        System.out.println("Corresponding Gregorian Date: " + year + "-" + month + "-" + day);
    }

    // Overloaded method to switch to Gregorian Calendar using a manually entered Julian date
    public void switchToGregorianCalendar(int manuallyEnteredJulianDay) {
        convertToGregorianCalendar(manuallyEnteredJulianDay);
        System.out.println("Corresponding Gregorian Date: " + year + "-" + month + "-" + day);
    }

    // Private method to calculate the maximum number of days in the current month
    private int calculateDaysInMonth() {
        return java.time.LocalDate.of(year, month, 1).lengthOfMonth();
    }

    // Conversion methods
    private int convertToJulianDate(int year, int month, int day) {
        int JD;
        int I = year;
        int J = month;
        int K = day;

        JD = K - 32075 + 1461 * (I + 4800 + (J - 14) / 12) / 4 + 367 * (J - 2 - (J - 14) / 12 * 12) / 12
                - 3 * ((I + 4900 + (J - 14) / 12) / 100) / 4;

        return JD;
    }

    private void convertToGregorianCalendar(int julianDate) {
        int L = julianDate + 68569;
        int N = 4 * L / 146097;
        L = L - (146097 * N + 3) / 4;
        int I = 4000 * (L + 1) / 1461001;
        L = L - 1461 * I / 4 + 31;
        int J = 80 * L / 2447;
        int K = L - 2447 * J / 80;
        L = J / 11;
        J = J + 2 - 12 * L;
        I = 100 * (N - 49) + I + L;

        this.year = I;
        this.month = J;
        this.day = K;
    }

    
    public static void main(String[] args) {
        // Use Scanner to get user input
        Scanner scanner = new Scanner(System.in);
    
        // Prompt user for the date format
        System.out.print("Enter the date format ('g' for Gregorian, 'j' for Julian): ");
        String dateFormat = scanner.next();
    
        if (dateFormat.equals("j")) {
            // Prompt and set the Julian day
            System.out.print("Enter the Julian day: ");
            int julianDay = scanner.nextInt();
    
            // Create an instance of the Day class with Julian date
            Date myDay = new Date(julianDay);
    
            // Display the corresponding Gregorian date
            System.out.println("Corresponding Gregorian Date: " + myDay.getYear() + "-"
                    + myDay.getMonth() + "-" + myDay.getDay());
        } else if (dateFormat.equals("g")) {
            // Prompt and set the year
            System.out.print("Enter the year: ");
            int year = scanner.nextInt();
    
            // Prompt and set the month
            System.out.print("Enter the month (1-12): ");
            int month = scanner.nextInt();
    
            // Prompt and set the day
            System.out.print("Enter the day: ");
            int day = scanner.nextInt();
    
            // Create an instance of the Day class with user-inputted date
            Date myDay = new Date(year, month, day);
    
            // Display the current date
            System.out.println("Current Date: " + myDay.getYear() + "-" + myDay.getMonth() + "-" + myDay.getDay());
    
            // Switch to Julian Calendar
            myDay.switchToJulianCalendar();
        } else {
            System.out.println("Invalid date format");
        }
    
        // Close the scanner
        scanner.close();
    }
    
}
