package lib;

import java.util.ArrayList;
import java.util.Date;



class User {
    int userID;
    String fName;
    String lName;
    String email;
    String password;

    // Method for user login
    boolean login(String enteredPassword) {
        return enteredPassword.equals(password);
    }

    // Method for updating user profile
    boolean updateProfile(String newFirstName, String newLastName, String newEmail) {
        fName = newFirstName;
        lName = newLastName;
        email = newEmail;
        return true;
    }
}

class Librarian extends User {
    // Method for adding a book to the library
    boolean addBook(Book book) {
        Library.books.add(book);
        return true;
    }

    // Method for removing a book from the library
    boolean removeBook(Book book) {
        Library.books.remove(book);
        return true;
    }

    // Method for managing user (placeholder implementation)
    void manageUser(User user) {
        // Implementation of manage user logic
    }
}

class Loan {
    int loanID;
    int userID;
    String ISBN;
    Date issueDate;
    Date dueDate;
    Date returnDate;

    // Method for issuing a book to a user
    boolean issueBook(Book book) {
        if (book.checkAvailability()) {
            issueDate = new Date();
            dueDate = calculateDueDate();
            return true;
        } else {
            return false;
        }
    }

    // Method for returning a borrowed book
    boolean returnBook(Book book) {
        returnDate = new Date();
        return true;
    }

    // Method for renewing a loan (placeholder implementation)
    boolean renewLoan() {
        // Implementation of renew loan logic
        return true;
    }

    // Helper method to calculate the due date
    private Date calculateDueDate() {
        // Calculate due date logic (e.g., 14 days from the issue date)
        // Placeholder implementation
        return new Date(issueDate.getTime() + 14 * 24 * 60 * 60 * 1000);
    }
}

class Book {
    String ISBN;
    String title;
    String author;
    int publicationYear;
    boolean isBorrowed;

    // Method for checking the availability of a book
    boolean checkAvailability() {
        return !isBorrowed;
    }

    // Method for updating book details
    void updateDetails(String newTitle, String newAuthor, int newPublicationYear) {
        title = newTitle;
        author = newAuthor;
        publicationYear = newPublicationYear;
    }
}

class Reservation {
    int reservationID;
    int userID;
    String ISBN;
    Date reservationDate;

    // Method for creating a reservation
    boolean createReservation(Book book) {
        if (!book.checkAvailability()) {
            reservationDate = new Date();
            return true;
        } else {
            return false;
        }
    }

    // Method for canceling a reservation (placeholder implementation)
    boolean cancelReservation() {
        // Implementation of cancel reservation logic
        return true;
    }
}

class Library {
    static ArrayList<Book> books = new ArrayList<>();
    static ArrayList<Loan> loans = new ArrayList<>();
    static ArrayList<Reservation> reservations = new ArrayList<>();

    // Method for displaying book information
    static void displayBookInfo(Book book) {
        System.out.println("ISBN: " + book.ISBN);
        System.out.println("Title: " + book.title);
        System.out.println("Author: " + book.author);
        System.out.println("Publication Year: " + book.publicationYear);
        System.out.println("Availability: " + (book.checkAvailability() ? "Available" : "Not Available"));
        System.out.println();
    }

    // Method for listing borrowed books for a user
    static void listBorrowedBooks(User user) {
        for (Loan loan : loans) {
            if (loan.userID == user.userID) {
                Book borrowedBook = findBookByISBN(loan.ISBN);
                if (borrowedBook != null) {
                    displayBookInfo(borrowedBook);
                }
            }
        }
    }

    // Method for finding a book by ISBN
    static Book findBookByISBN(String ISBN) {
        for (Book book : books) {
            if (book.ISBN.equals(ISBN)) {
                return book;
            }
        }
        return null;
    }
}

public class librarySystem {
    public static void main(String[] args) {
        // Example usage of the Library Management System classes
        Librarian librarian = new Librarian();
        Book newBook = new Book();
        newBook.ISBN = "123456789";
        newBook.title = "Sample Book";
        newBook.author = "John Doe";
        newBook.publicationYear = 2022;
        librarian.addBook(newBook);

        User user = new User();
        user.userID = 1;

        Loan loan = new Loan();
        loan.userID = user.userID;
        loan.ISBN = "123456789";
        librarian.removeBook(newBook);
        if (loan.issueBook(newBook)) {
            Library.loans.add(loan);
            System.out.println("Book issued successfully");
        } else {
            System.out.println("Book not available for loan");
        }

        // Display book information
        Book sampleBook = Library.findBookByISBN("123456789");
        if (sampleBook != null) {
            Library.displayBookInfo(sampleBook);
        }

        // Display borrowed books for the user
        System.out.println("Borrowed Books:");
        Library.listBorrowedBooks(user);
    }
}
