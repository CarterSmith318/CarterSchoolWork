package lib;

public class LibraryTest {
    public static void main(String[] args) {
        testLibrarian();
        testRegularUser();
        testReservationSystem();
        testUserProfileUpdate();
        testLoanSystem();
        testBookDetailsUpdate();
    }

    private static void testLibrarian() {
        Librarian librarian = new Librarian();
        
        // Add a book for testing reservation and loan systems
        Book reservableBook = new Book();
        reservableBook.ISBN = "987654321";
        reservableBook.title = "Reservable Book";
        reservableBook.author = "Author";
        reservableBook.publicationYear = 2022;
        librarian.addBook(reservableBook);
    }

    private static void testRegularUser() {
        User user = new User();
        user.userID = 2;

        Loan loan = new Loan();
        loan.userID = user.userID;

        Book reservableBook = Library.findBookByISBN("987654321");
        if (loan.issueBook(reservableBook)) {
            Library.loans.add(loan);
            System.out.println("Borrowing a book:");
            Library.displayBookInfo(reservableBook);
        } else {
            System.out.println("Book not available for loan");
        }

        // Display borrowed books for the user
        System.out.println("Borrowed Books:");
        Library.listBorrowedBooks(user);
    }

    private static void testReservationSystem() {
        User user = new User();
        user.userID = 3;

        System.out.println("Reservation System Actions:");

        // User tries to reserve a book
        Book reservableBook = Library.findBookByISBN("987654321");
        Reservation reservation = new Reservation();
        reservation.userID = user.userID;
        reservation.ISBN = "987654321";

        if (reservableBook != null && reservation.createReservation(reservableBook)) {
            Library.reservations.add(reservation);
            System.out.println("Reserving a book:");
            Library.displayBookInfo(reservableBook);
        } else {
            System.out.println("Book not available for reservation");
        }

        // User cancels the reservation
        if (Library.reservations.contains(reservation)) {
            Library.reservations.remove(reservation);
            System.out.println("Canceling the reservation:");
            Library.displayBookInfo(reservableBook);  // Should show as available again
        } else {
            System.out.println("Reservation not found");
        }
    }

    private static void testUserProfileUpdate() {
        User user = new User();
        user.userID = 4;
        user.fName = "John";
        user.lName = "Doe";
        user.email = "john.doe@example.com";
        user.password = "password123";

        System.out.println("User Profile Update:");

        // Display original user profile
        System.out.println("Original User Profile:");
        System.out.println("Name: " + user.fName + " " + user.lName);
        System.out.println("Email: " + user.email);

        // Update user profile
        user.updateProfile("Jane", "Smith", "jane.smith@example.com");

        // Display updated user profile
        System.out.println("Updated User Profile:");
        System.out.println("Name: " + user.fName + " " + user.lName);
        System.out.println("Email: " + user.email);
        System.out.println();
    }

    private static void testLoanSystem() {
        User user = new User();
        user.userID = 5;

        Loan loan = new Loan();
        loan.userID = user.userID;
        loan.ISBN = "987654321";

        System.out.println("Loan System Actions:");

        // Loan a book
        Book loanableBook = Library.findBookByISBN("987654321");
        if (loanableBook != null && loan.issueBook(loanableBook)) {
            Library.loans.add(loan);
            System.out.println("Borrowing a book:");
            Library.displayBookInfo(loanableBook);  // Should show as not available
        } else {
            System.out.println("Book not available for loan");
        }

        // Renew the loan
        if (loan.renewLoan()) {
            System.out.println("Renewing the loan:");
            // Display book information after renewal
            Library.displayBookInfo(loanableBook);
        } else {
            System.out.println("Loan cannot be renewed");
        }
        System.out.println();
    }

    private static void testBookDetailsUpdate() {
        Librarian librarian = new Librarian();
        Book existingBook = Library.findBookByISBN("987654321");

        System.out.println("Book Details Update:");

        // Display original book details
        System.out.println("Original Book Details:");
        Library.displayBookInfo(existingBook);

        // Update book details
        existingBook.updateDetails("Updated Book", "New Author", 2023);

        // Display updated book details
        System.out.println("Updated Book Details:");
        Library.displayBookInfo(existingBook);
        System.out.println();
    }
}
